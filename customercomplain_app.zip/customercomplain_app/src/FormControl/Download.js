import React, { useState } from 'react';

const FileDownload = () => {
  const [fileData, setFileData] = useState(null);

  const downloadFile = () => {
    // Replace 'your_api_endpoint' with the actual URL of your Web API endpoint
    const apiUrl = '/api/downloadfile'; // Example endpoint URL
    fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.blob(); // Convert the response to a Blob
      })
      .then((blob) => {
        setFileData(blob); 
        if (blob) {
            // Create a URL for the Blob
            const url = window.URL.createObjectURL(blob);
      
            // Create a temporary <a> element to trigger the download
            const a = document.createElement('a');
            a.href = url;
            a.download = 'your_filename.ext'; // Replace with the desired filename
            document.body.appendChild(a);
            a.click();
      
            // Clean up resources
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
          }// Store the blob data in state
      })
      .catch((error) => {
        console.error('There was a problem with the fetch operation:', error);
      });
  };

  const handleDownload = () => {
    downloadFile();
    
  };

  return (
    <div>
      <button onClick={downloadFile}>Download File</button>
      <button onClick={handleDownload}>Download</button>
    </div>
  );
};

export default FileDownload;
