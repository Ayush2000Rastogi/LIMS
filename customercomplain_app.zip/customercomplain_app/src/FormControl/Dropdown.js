import React, { Component } from 'react';
import { post } from '../app/ApiMethod';


class SelectComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      location: null,
      sublocation: null,
      options: null
    };
  }

  componentDidMount() {
    this.BindDDL(this.props.param);
  }

  async BindDDL(param) {
    try {
      var options = await post(this.props.url, param);
      this.setState({ options: options.d });
    } catch (error) {
      // Handle errors
    }
  }

  render() {
    const { name, value, onChange } = this.props;
    return (
      <div>
        {this.state.options != null && (
          <select className='form-control' name={name} value={value} onChange={onChange}>
            <option key="0" value={''}>Please Select</option>
            {this.state.options?.map((option) => (
              <option key={option?.ID} value={option?.ID}>
                {option?.VAL}
              </option>
            ))}
          </select>)}
      </div>
    );
  }
}

export default SelectComponent;
