import React, { Component } from 'react'
import { Button, Modal } from 'react-bootstrap';
import '../form-elements/Modal.css';
import { post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import { InsertEscalationData, UpdateEscalationDays, materialUrl } from '../Constant';
import secureLocalStorage from 'react-secure-storage';
import Select from 'react-select';
import Swal from 'sweetalert2';


export class EscalationModal extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            USERNAME: UserName,
            dataList: this.props.selectedData?.datList || [],
            isPNoModal: this.props.isPNoModal,
            btnLoading: false,
            type: this.props.type,
            pNo: "",
            matordepId: "",
            selectedData: this.props.selectedData,
            escalationDays: null
        }
    }

    componentDidMount() {
        this.BindMaterialList(materialUrl);
    }

    async BindMaterialList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                materialList: opt,
            });
        } catch (error) {
        }
    }

    handleClose = (event) => {
        this.props.closeDialog();
    };

    handleValueChange = (event, name) => {
        this.setState({ [name]: event.target.value })
    }

    checkBtnDisabled = () => {
        let isDisabled = true
        if (this.state.isPNoModal) {
            if (this.state.matordepId && this.state.pNo)
                isDisabled = false
        }
        else {
            if (this.state.escalationDays && this.state?.escalationDays !== this.state?.selectedData?.escalationDays)
                isDisabled = false
            if (!this.state.isEdit && this.state?.[this.props.subType])
                isDisabled = false
        }
        return isDisabled
    }

    handleSubmit = () => {
        if (!this.state.isPNoModal) {
            let payload = {
                "CODE": this.state.type === 'material' ? "CC_ASGNMT" : "CC_ASGND",
                "VALUE": this.state.escalationDays,
                "USERNAME": this.state.USERNAME
            }
            this.submitData(payload, UpdateEscalationDays);
        }
        else {
            let payload = {
                "MATORDEPTID": this.state?.matordepId,
                "PNO": this.state?.pNo,
                "TYPE": this.state.type === 'material' ? "ASSIGNMENT" : "ASSIGNED",
                "USERNAME": this.state.USERNAME
            }
            this.submitData(payload, InsertEscalationData);
        }
    }

    async submitData(param, url) {
        try {
            this.setState({ btnLoading: true })
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({ btnLoading: false })
            }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
            this.handleClose()
        } catch (error) {
            this.setState({ btnLoading: false })
            this.handleClose()
            Swal.fire("", "Error", 'error');
        }
    }

    handleChange = (valueObj, name) => {
        this.setState({ [name]: valueObj?.value || null })
    }


    render() {
        let isBtnDisabled = this.checkBtnDisabled()
        return (
            <Modal show={this.props.modalShow}
                onHide={this.handleClose}
                centered
                className="my-modal"
                backdrop="static"
                keyboard={false}>
                <Modal.Header closeButton >
                    <Modal.Title> {this.state.isPNoModal ? 'Add P.No' : 'Edit Escalation Days'}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {!this.state.isPNoModal ? <form>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Escalation Days</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field3"
                                    rows="1"
                                    defaultValue={this.state?.selectedData?.escalationDays}
                                    placeholder='Enter Escalation Days'
                                    maxLength={'2'}
                                    onChange={(event) => this.handleValueChange(event, 'escalationDays')}></textarea>
                            </div>
                        </div>
                    </form> :
                        <form>
                            <div className="row mb-2">
                                <div className="col-md-5">
                                    <label><span className='required'>*</span>{this.state.type}</label>
                                </div>
                                <div className="col-md-7 ml-auto">
                                    <div className='form-group mb-0'>
                                        <Select
                                            menuPortalTarget={document.body}
                                            styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                            onChange={(valueObj) => this.handleChange(valueObj, 'matordepId')}
                                            options={this.state.dataList}
                                            closeMenuOnSelect={true}
                                            hideSelectedOptions={false}
                                            placeholder={`Select ${this.state.type}`}
                                            defaultValue={""}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-5">
                                    <label><span className='required'>*</span>{this.props.subType}P. No</label>
                                </div>
                                <div className="col-md-7 ml-auto">
                                    <textarea
                                        className="form-control"
                                        id="field3"
                                        rows="1"
                                        defaultValue={''}
                                        placeholder={`Enter P.No`}
                                        maxLength={'20'}
                                        onChange={(event) => this.handleValueChange(event, 'pNo')}></textarea>
                                </div>
                            </div>
                        </form>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={this.handleSubmit}
                        disabled={isBtnDisabled}
                        className={isBtnDisabled ? 'btn disabled not-allowed' : 'btn'} >
                        Submit
                        {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                    </Button>
                </Modal.Footer>
            </Modal >
        )
    }
}
export default EscalationModal