import React, { Component } from 'react'
import { Button, Modal, Form } from 'react-bootstrap';
import '../form-elements/Modal.css';
import { downloadFile, post, postFile } from '../ApiMethod';
import Swal from 'sweetalert2';
import '../Pages/User_Complaint.css';
import { GetCAPADataById, InsertCAPAUrl, capaDownloadUrl, capaUploadFileurl } from '../Constant';
import secureLocalStorage from 'react-secure-storage';
import bsCustomFileInput from 'bs-custom-file-input'


export class ComplaintModal extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            abnormality: "",
            reason: "",
            counterMeasure: "",
            responsibility: "",
            remarks: "",
            targetDate: "",
            completionDate: "",
            attachment: "",
            USERNAME: UserName,
            btnLoading: false,
            setSelectedFile: null,
        }
    }

    componentDidMount() {
        bsCustomFileInput.init()
        this.BindCAPADataById(GetCAPADataById, { "ComplaintId": this.props.complainId });
    }

    async UploadFileData(id) {
        if (this.state.setSelectedFile != null) {
            const formData = new FormData();
            formData.append('file', this.state.setSelectedFile);
            formData.append('COMPLAINTID', id);
            formData.append('UserName', this.state.USERNAME);
            var options = await postFile(capaUploadFileurl, formData);
            // Swal.fire("", "File Uploaded Successfully", "info");

        }
    }

    async BindCAPADataById(url, param) {
        try {
            var options = await post(url, param);
            let data = options?.d[0] || {}
            if (Object.keys(data)?.length > 0) {
                this.setState({
                    abnormality: data?.ABNDEVIATION,
                    reason: data?.REASON,
                    counterMeasure: data?.COUNTERMEASURE,
                    responsibility: data?.RESPOSIBILITY,
                    remarks: data?.REMARK,
                    completionDate: data?.COMPLAINTDATE,
                    targetDate: data?.TARGETDATE,
                    attachment: data?.ATTACHMENT
                });
            }
        } catch (error) {
        }
    }
    handleClose = (event) => {
        this.props.closeDialog();
        this.props.submitCAPA(false)
        this.setState({
            abnormality: "",
            reason: "",
            counterMeasure: "",
            responsibility: "",
            remarks: "",
            targetDate: "",
            completionDate: "",
            btnLoading: false,
            setSelectedFile: null,
            attachment: ""
        })
    };
    handleValueChange = (event, name) => {
        this.setState({ [name]: event.target.value })
    }

    checkBtnDisabled = () => {
        let objData = this.state
        if (objData?.abnormality && objData?.reason && objData?.counterMeasure && objData?.responsibility &&
            objData?.remarks && objData?.targetDate && objData?.completionDate && objData?.USERNAME)
            return false
        else
            return true
    }

    handleFileChange = (event) => {
        this.setState({ setSelectedFile: event.target.files[0] });
    };

    handleSubmit = () => {
        if (this.props.complainId) {
            this.props.submitCAPA(true)
            this.setState({ btnLoading: true })
            let payload = {
                "TCC_CAPA_ID": "",
                "COMPLAINTID": this.props.complainId,
                "TCC_ABN_DEV": this.state.abnormality,
                "TCC_REASON": this.state.reason,
                "TCC_CNTRMSR": this.state.counterMeasure,
                "TCC_RESPONSIBILITY": this.state.responsibility,
                "TCC_TARGET_DT": this.state.targetDate,
                "TCC_COMPLTN_DT": this.state.completionDate,
                "TCC_REMARK": this.state.remarks,
                "USERNAME": this.state.USERNAME,
                "PLANT": "",
                "INITIATOR": this.props?.INITIATOR
            }
            this.submitCAPA(InsertCAPAUrl, payload);
        }
    }

    onDownload = (id) => {
        downloadFile(capaDownloadUrl, id);
    }

    async submitCAPA(url, param) {
        try {
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({ btnLoading: false })
            }
            if (options["ID"]?.length > 0) {
                await this.UploadFileData(this.props.complainId);
            }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
            this.handleClose()
        } catch (error) {
            this.setState({ btnLoading: false })
            this.handleClose()
            Swal.fire("", "Error", 'error');
        }
    }


    render() {
        let isBtnDisabled = this.checkBtnDisabled()
        return (
            <Modal show={this.props.modalShow}
                onHide={this.handleClose}
                centered
                className="my-modal"
                backdrop="static"
                keyboard={false}>
                <Modal.Header closeButton >
                    <Modal.Title>Comment Section for {this.props.complainId}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <form>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Abnormality/Deviation</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field1" rows="2"
                                    defaultValue={this.state.abnormality}
                                    placeholder='Record Abnormality/Deviation (Max 100 Char)'
                                    maxLength={'100'}
                                    onChange={(event) => this.handleValueChange(event, 'abnormality')}></textarea>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Reason for Abnormality/Deviation</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field2"
                                    defaultValue={this.state.reason}
                                    rows="2"
                                    placeholder='Record Reason for Abnormality/Deviation (Max 100 Char)'
                                    maxLength={'100'}
                                    onChange={(event) => this.handleValueChange(event, 'reason')}></textarea>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Counter Measure</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field3" rows="2"
                                    defaultValue={this.state.counterMeasure}
                                    placeholder='Enter Counter Measure taken(Max 100 Char)'
                                    maxLength={'100'}
                                    onChange={(event) => this.handleValueChange(event, 'counterMeasure')}></textarea>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Responsibility</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field4" rows="2"
                                    defaultValue={this.state.responsibility}
                                    placeholder='Please Enter User Name(Max 100 Char)'
                                    maxLength={'100'}
                                    onChange={(event) => this.handleValueChange(event, 'responsibility')}></textarea>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Target Date</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <input type="date"
                                    defaultValue={this.state.targetDate}
                                    className="form-control"
                                    onChange={(event) => this.handleValueChange(event, 'targetDate')} />
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Completion Date</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <input type="date"
                                    defaultValue={this.state.completionDate}
                                    className="form-control"
                                    onChange={(event) => this.handleValueChange(event, 'completionDate')} />
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Remarks</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field5"
                                    rows="2"
                                    defaultValue={this.state.remarks}
                                    placeholder='Enter Any remarks related to the analysis done(Max 100 Char)'
                                    maxLength={'100'}
                                    onChange={(event) => this.handleValueChange(event, 'remarks')}></textarea>
                            </div>
                        </div>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label>File Attachment</label>
                            </div>
                            <div className={`${this.state?.attachment ? "col-md-6" : "col-md-7"}`}>
                                <Form.Group>
                                    <div className="custom-file">
                                        <Form.Control type="file" className="form-control visibility-hidden" id="customFileLang" lang="es" onChange={(e) => this.handleFileChange(e)} />
                                        <label className="custom-file-label" htmlFor="customFileLang">Upload file</label>
                                    </div>

                                </Form.Group>
                            </div>
                            {this.state?.attachment &&
                                <div className="col-md-1 pl-0">
                                    <h1><i role="button" className="mdi mdi-file-import icon" onClick={this.onDownload.bind(this, this.props.complainId)}></i></h1>
                                </div>
                            }
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={this.handleSubmit}
                        className={isBtnDisabled ? 'btn disabled not-allowed' : 'btn'} disabled={isBtnDisabled}>
                        Submit
                        {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}

                    </Button>
                </Modal.Footer>
            </Modal >
        )
    }
}

export default ComplaintModal