import React, { Component } from 'react'
import { Button, Modal } from 'react-bootstrap';
import '../form-elements/Modal.css';
import { post } from '../ApiMethod';
import Swal from 'sweetalert2';
import '../Pages/User_Complaint.css';
import secureLocalStorage from 'react-secure-storage';
import Select from 'react-select';
import { UpdateComplaint, gradeUrl, impactUrl, natureUrl, subNatureUrl, sublocationUrl } from '../Constant';
import { InputOption } from '../Pages/User_Complaint';
import MyStatefulEditor from '../../FormControl/Richtextbox';


export class ComplaintUpdateModal extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        let data = this.props?.selectedData || {}
        this.state = {
            gradeList: [],
            USERNAME: UserName,
            locationList: this.props?.locationList || [],
            materialList: this.props?.materialList || [],
            plantList: [],
            natureList: [],
            subNatureList: [],
            impactList: [],
            location: data?.LOCID ? { value: data?.LOCID, label: data?.LOCATION } : {},
            plant: data?.PLANTID ? { value: data?.PLANTID, label: data?.PLANT } : {},
            grade: data?.GRADEID ? { value: data?.GRADEID, label: data?.GRADE } : {},
            nature: data?.NATUREID ? { value: data?.NATUREID, label: data?.NATURE } : {},
            subNature: data?.SUBNATUREID ? { value: data?.SUBNATUREID, label: data?.SUBNATUREID } : {},
            material: data?.MATERIALID ? { value: data?.MATERIALID, label: data?.MATERIAL } : {},
            impact: [],
            comment: data?.DESCRIPTION || "",
            selectedData: data || {},
            isSubNatureDDLVisible: false,
        }
    }

    componentDidMount() {
        if (this.state?.selectedData?.NATUREID === 'PCI_Offspec_Cargo-_Chemical_Properties') {
            this.setState({
                isSubNatureDDLVisible: true,
            });
            this.BindSubNatureDDL(subNatureUrl, {
                NATUREID: this.state?.selectedData?.NATUREID,
                MATERIALID: this.state?.selectedData?.MATERIALID
            });
        }
        if (this.state?.selectedData?.LOCID) {
            this.BindPlantDDL(sublocationUrl, { LOCID: this.state?.selectedData?.LOCID });
        }
        if (this.state?.selectedData?.MATERIALID) {
            this.BindNatureDDL(natureUrl, { MATID: this.state?.selectedData?.MATERIALID });
            this.BindGradeDDL(gradeUrl, { MATID: this.state?.selectedData?.MATERIALID });
            this.BindImpactDDL(impactUrl, { MATID: this.state?.selectedData?.MATERIALID });
        }
        let impactData = []
        let valueArray = this.props?.selectedData?.IMPACTID.split(',');
        let labelArray = this.props?.selectedData?.IMPACT.split(',');
        for (var i = 0; i < valueArray.length; i++) {
            impactData.push({
                value: valueArray[i],
                label: labelArray[i]
            })
        }
        this.setState({ impact: impactData })
    }

    async BindGradeDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                gradeList: opt,
            });
        } catch (error) {
            // Handle errors
        }
    }

    async BindNatureDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                natureList: opt,
            });
        } catch (error) {
            // Handle errors
        }
    }

    async BindPlantDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                plantList: opt,
            });
        } catch (error) {
        }
    }

    async BindSubNatureDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["NAME"] },
                )
            }
            this.setState({
                subNatureList: opt,
            });
        } catch (error) {
        }
    }

    async BindImpactDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({ impactList: opt, SELEIMPACTID: [], IMPACTID: [] });
            // Handle the data
        } catch (error) {
            // Handle errors
        }
    }

    handleChange = (valueObj, name) => {
        this.setState({ [name]: valueObj })
        if (name === 'location') {
            this.setState({
                plant: null,
            });
            if (valueObj?.value) {
                this.BindPlantDDL(sublocationUrl, { LOCID: valueObj?.value });
            }
            else {
                this.setState({
                    plantList: [],
                });
            }
        }
        if (name === 'material') {
            this.setState({
                grade: null,
                nature: null,
                impact: [],
                isSubNatureDDLVisible: false,
                subNature: null,
            });
            if (valueObj?.value) {
                this.BindNatureDDL(natureUrl, { MATID: valueObj.value });
                this.BindGradeDDL(gradeUrl, { MATID: valueObj.value });
                this.BindImpactDDL(impactUrl, { MATID: valueObj.value });
            }
            else {
                this.setState({
                    natureList: [],
                    gradeList: [],
                    impactList: []
                });
            }
        }
        if (name === 'nature' && valueObj?.value && valueObj?.value === 'PCI_Offspec_Cargo-_Chemical_Properties') {
            this.setState({
                isSubNatureDDLVisible: true,
            });
            this.BindSubNatureDDL(subNatureUrl, {
                NATUREID: valueObj?.value,
                MATERIALID: this.state?.material?.value
            });
        }
    }
    handleSubmit = () => {
        let impactData = []
        for (var i = 0; i < this.state.impact?.length; i++) {
            impactData.push({
                IMPACTID: this.state.impact[i]["value"],
                USERNAME: this.state.USERNAME
            })
        }
        var payload = {
            complaint: {
                COMPLAINTID: this.state?.selectedData?.ID,
                LOCID: this.state.location?.value,
                PLANTID: this.state.plant?.value,
                MATID: this.state.material?.value,
                GRADEID: this.state.grade?.value,
                NATUREID: this.state.nature?.value,
                SUBNATUREID: this.state.subNature?.value || null,
                COMMENT: this.state.comment,
                USERNAME: this.state.USERNAME
            },
            IMPACTID: impactData,
        }
        this.updateComplaint(payload, UpdateComplaint);
    }

    async updateComplaint(param, url) {
        this.setState({ btnLoading: true })
        try {
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({ btnLoading: false })
            }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
            this.handleClose()
        } catch (error) {
            this.setState({ btnLoading: false })
            this.handleClose()
            Swal.fire("", "Error", 'error');
        }
    }

    handleImpactChange = (event) => {
        this.setState({
            impact: event || [],
        });
    };

    handleClose = (event) => {
        this.props.closeDialog();
    };

    onRichChange = (value) => {
        try {
            this.setState({
                comment: value
            });
        }
        catch (e) { }
    };

    checkBtnDisabled = () => {
        let flag = true
        if (this.state.location?.value && this.state.plant?.value && this.state.material?.value && this.state.material?.value && this.state.grade?.value && this.state.nature?.value && this.state.comment && this.state?.impact?.length > 0)
            flag = false
        else
            flag = true
        return flag
    }


    render() {
        let isBtnDisabled = this.checkBtnDisabled(this)
        return (
            <Modal show={this.props.modalShow}
                onHide={this.handleClose}
                centered
                className="my-modal1"
                backdrop="static"
                keyboard={false}>
                <Modal.Header closeButton >
                    <Modal.Title>Update Complaint : {this.state?.selectedData?.ID}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="row pl-3">
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Location:</label>
                                <Select
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={(valueObj) => this.handleChange(valueObj, 'location')}
                                    options={this.state.locationList}
                                    closeMenuOnSelect={true}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Location'}
                                    isClearable={true}
                                    value={this.state.location}
                                />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Plant:</label>
                                <Select
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={(valueObj) => this.handleChange(valueObj, 'plant')}
                                    options={this.state.plantList}
                                    closeMenuOnSelect={true}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Plant'}
                                    isClearable={true}
                                    value={this.state.plant}
                                />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Material:</label>
                                <Select
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={(valueObj) => this.handleChange(valueObj, 'material')}
                                    options={this.state.materialList}
                                    closeMenuOnSelect={true}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Material'}
                                    isClearable={true}
                                    value={this.state.material}
                                />
                            </div>
                        </div>

                    </div>
                    <div className="row pl-3">
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Nature:</label>
                                <Select
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={(valueObj) => this.handleChange(valueObj, 'nature')}
                                    options={this.state.natureList}
                                    closeMenuOnSelect={true}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Nature'}
                                    isClearable={true}
                                    value={this.state.nature}
                                />
                            </div>
                        </div>
                        {this.state.isSubNatureDDLVisible &&
                            <div className="col-md-4">
                                <div className='form-group'>
                                    <label><span className='required'>*</span>SubNature:</label>
                                    <Select
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                        onChange={(valueObj) => this.handleChange(valueObj, 'subNature')}
                                        options={this.state.subNatureList}
                                        closeMenuOnSelect={true}
                                        hideSelectedOptions={false}
                                        placeholder={'Select SubNature'}
                                        isClearable={true}
                                        value={this.state.subNature}
                                    />
                                </div>
                            </div>
                        }
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Grade:</label>
                                <Select
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={(valueObj) => this.handleChange(valueObj, 'grade')}
                                    options={this.state.gradeList}
                                    closeMenuOnSelect={true}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Grade'}
                                    isClearable={true}
                                    value={this.state.grade}
                                />
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className='form-group'>
                                <label><span className='required'>*</span>Impact:</label>
                                <Select
                                    isMulti
                                    menuPortalTarget={document.body}
                                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                    onChange={this.handleImpactChange}
                                    options={this.state.impactList}
                                    closeMenuOnSelect={false}
                                    hideSelectedOptions={false}
                                    placeholder={'Select Impact'}
                                    components={{
                                        Option: InputOption
                                    }}
                                    value={this.state.impact.map(ele => ele)}
                                />
                            </div>
                        </div>
                    </div>
                    <div className='row pl-3'>
                        <div className='col-md-12'>
                            <div className='form-group'>
                                <label><span className='required'>*</span>Please Enter Complaint Description</label>
                                <MyStatefulEditor defaultValue={this.state.comment} onRichChange={this.onRichChange}></MyStatefulEditor>
                            </div>
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={this.handleSubmit}
                        className={'btn'} disabled={isBtnDisabled}>
                        Update
                        {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                    </Button>
                </Modal.Footer>
            </Modal >
        )
    }
}

export default ComplaintUpdateModal