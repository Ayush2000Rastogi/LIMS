import React, { Component } from 'react'
import { Button, Modal, } from 'react-bootstrap';
import '../form-elements/Modal.css';
import { post } from '../ApiMethod';
import Swal from 'sweetalert2';
import '../Pages/User_Complaint.css';

export class DeleteModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    handleSubmit = () => {
        if (this.props?.URL) {
            this.setState({ btnLoading: true })
            this.deleteData(this.props?.payload, this.props?.URL);
        }
    }

    async deleteData(param, url) {
        try {
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({ btnLoading: false })
            }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
            this.handleClose()
        } catch (error) {
            this.setState({ btnLoading: false })
            this.handleClose()
            Swal.fire("", "Error", 'error');
        }
    }

    handleClose = (event) => {
        this.props.closeDialog();
    };


    render() {
        return (
            <Modal show={this.props.modalShow}
                onHide={this.handleClose}
                centered
                className="my-modal"
                backdrop="static"
                keyboard={false}>
                <Modal.Header closeButton >
                    <Modal.Title>Delete Confirmation</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <p>Are you sure you want to delete?</p>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Cancel
                    </Button>
                    <Button variant="primary" onClick={this.handleSubmit}
                        className={'btn'} >
                        Delete
                        {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                    </Button>
                </Modal.Footer>
            </Modal >
        )
    }
}

export default DeleteModal