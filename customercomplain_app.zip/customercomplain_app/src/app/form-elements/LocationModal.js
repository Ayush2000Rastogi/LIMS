import React, { Component } from 'react'
import { Button, Modal } from 'react-bootstrap';
import '../form-elements/Modal.css';
import { post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import { InsertUpdateDeleteLocation, locationUrl, InsertUpdateDeleteSubLocation } from '../Constant';
import secureLocalStorage from 'react-secure-storage';
import Select from 'react-select';
import Swal from 'sweetalert2';


export class LocationModal extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            USERNAME: UserName,
            isLocationModal: this.props.isLocationModal,
            btnLoading: false,
            locationList: [],
            location: null,
            plantId: null,
            plantName: null,
            locationId: null,
            locationName: null,
            isEdit: this.props.dialogMode === 'edit' ? true : false,
            selectedLocation: this.props.selectedLocation
        }
    }

    componentDidMount() {
        this.BindLocationList(locationUrl);
        if (this.state.isLocationModal && this.state.isEdit) {
            this.setState({ locationName: this.state.selectedLocation?.LOCNAME })
        }
        if (!this.state.isLocationModal && this.state.isEdit) {
            this.setState({ plantName: this.state.selectedLocation?.SUBLOCNAME })
        }
    }

    async BindLocationList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                locationList: opt,
            });
        } catch (error) {
        }
    }

    handleClose = (event) => {
        this.props.closeDialog();
    };

    handleValueChange = (event, name) => {
        this.setState({ [name]: event.target.value })
    }


    checkBtnDisabled = () => {
        let isDisabled = true
        if (this.state.isLocationModal) {
            if (this.state.isEdit && this.state.locationName && this.state.locationName !== this.state.selectedLocation?.LOCNAME)
                isDisabled = false
            if (!this.state.isEdit && this.state.locationName)
                isDisabled = false
        }
        else {
            if (this.state.isEdit && this.state?.plantName && this.state?.plantName !== this.state.selectedLocation?.SUBLOCNAME)
                isDisabled = false
            if (!this.state.isEdit && this.state?.plantName)
                isDisabled = false
        }
        return isDisabled
    }

    handleSubmit = () => {
        if (this.state.isLocationModal) {
            let payload = {
                "TYPE": this.state.isEdit ? 'UPDATE' : 'INSERT',
                "LOCID": this.state.isEdit ? this.state.selectedLocation?.LOCID : "",
                "LOCNAME": this.state.locationName,
                "USERNAME": this.state.USERNAME
            }
            this.submitData(payload, InsertUpdateDeleteLocation);
        }
        else {
            let payload = {
                "TYPE": this.state.isEdit ? 'UPDATE' : 'INSERT',
                "LOCID": this.state.isEdit ? this.state.selectedLocation?.LOCID : this.state.location,
                "SUBLOCID": this.state.isEdit ? this.state.selectedLocation?.SUBLOCID : "",
                "SUBLOCNAME": this.state.plantName,
                "USERNAME": this.state.USERNAME
            }
            this.submitData(payload, InsertUpdateDeleteSubLocation);
        }
    }

    async submitData(param, url) {
        try {
            this.setState({ btnLoading: true })
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({ btnLoading: false })
            }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
            this.handleClose()
        } catch (error) {
            this.setState({ btnLoading: false })
            this.handleClose()
            Swal.fire("", "Error", 'error');
        }
    }


    handleChange = (valueObj, name) => {
        this.setState({ [name]: valueObj?.value || null })
    }



    render() {
        let isBtnDisabled = this.checkBtnDisabled()
        return (
            <Modal show={this.props.modalShow}
                onHide={this.handleClose}
                centered
                className="my-modal"
                backdrop="static"
                keyboard={false}>
                <Modal.Header closeButton >
                    <Modal.Title>{this.state.isEdit ? 'UPDATE' : 'ADD'} {this.state.isLocationModal ? 'LOCATION' : "PLANT"}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {this.state.isLocationModal ? <form>
                        <div className="row mb-2">
                            <div className="col-md-5">
                                <label><span className='required'>*</span>Location Name</label>
                            </div>
                            <div className="col-md-7 ml-auto">
                                <textarea
                                    className="form-control"
                                    id="field3"
                                    rows="1"
                                    defaultValue={this.state.selectedLocation.LOCNAME}
                                    placeholder='Enter Location Name'
                                    maxLength={'30'}
                                    onChange={(event) => this.handleValueChange(event, 'locationName')}></textarea>
                            </div>
                        </div>
                    </form> :
                        <form>
                            <div className="row mb-2">
                                <div className="col-md-5">
                                    <label><span className='required'>*</span>Location</label>
                                </div>
                                <div className="col-md-7 ml-auto">
                                    <div className='form-group mb-0'>
                                        <Select
                                            menuPortalTarget={document.body}
                                            styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                            onChange={(valueObj) => this.handleChange(valueObj, 'location')}
                                            options={this.state.locationList}
                                            closeMenuOnSelect={true}
                                            hideSelectedOptions={false}
                                            placeholder={'Select Location'}
                                            isClearable={!this.state.isEdit}
                                            defaultValue={this.state?.selectedLocation?.LOCID ? { value: this.state.selectedLocation.LOCID, label: this.state.selectedLocation.LOCID } : ""}
                                            isDisabled={this.state.isEdit}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className="row mb-2">
                                <div className="col-md-5">
                                    <label><span className='required'>*</span>Plant Name</label>
                                </div>
                                <div className="col-md-7 ml-auto">
                                    <textarea
                                        className="form-control"
                                        id="field3"
                                        rows="1"
                                        defaultValue={this.state.selectedLocation.SUBLOCNAME}
                                        placeholder='Enter Plant Name'
                                        maxLength={'30'}
                                        onChange={(event) => this.handleValueChange(event, 'plantName')}></textarea>
                                </div>
                            </div>
                        </form>
                    }
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={this.handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={this.handleSubmit}
                        disabled={isBtnDisabled}
                        className={isBtnDisabled ? 'btn disabled not-allowed' : 'btn'}>
                        Submit
                        {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                    </Button>
                </Modal.Footer>
            </Modal >
        )
    }
}

export default LocationModal