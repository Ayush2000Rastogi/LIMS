// api.js

// const BASE_URL = 'http://localhost:51801/api'; // Replace with your API base URL
//const BASE_URL="https://tslappwebapiqa.tatasteel.co.in/Customer_Complaint_API/api";
const BASE_URL="https://webapp30.corp.tatasteel.com:8182/customer_complaint_api/api";
//const BASE_URL="https://webapp30.corp.tatasteel.com:8182/Customer_Complaint_API/api/master/GetMenuList";
                 
export const AUTH_URL="https://immes.corp.tatasteel.com/api/Authentication";

async function handleResponse(response) {

  return await response;
}

export function get(endpoint) {
  return fetch(`${BASE_URL}/${endpoint}`)
    .then((response) => {
      return response.json().then((data) => {
        return data;
      }).catch((err) => {
        console.error(err);
      })
    });
}

export async function post(endpoint, data) {
  const response = await fetch(`${BASE_URL}/${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  });
  return response.json();
}
export async function postFile(endpoint, data) {
  await fetch(`${BASE_URL}/${endpoint}`, {
    method: 'POST',
    body: data,
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data); // Handle the server response here
    })
    .catch((error) => {
      console.error('Error:', error);
    });
}

export function put(endpoint, data) {
  try {
    const response = fetch(`${BASE_URL}${endpoint}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    return handleResponse(response);
  } catch (error) {
    throw new Error(`Failed to put data: ${error.message}`);
  }
}

export function del(endpoint) {
  try {
    const response = fetch(`${BASE_URL}${endpoint}`, {
      method: 'DELETE',
    });
    return handleResponse(response);
  } catch (error) {
    throw new Error(`Failed to delete data: ${error.message}`);
  }
}

export async function downloadFile(endpoint, ID) {
  // Set the file's endpoint URL
  // Replace with the actual API endpoint

  //this.setState({ loading: true });
  let fileName = ''
  await fetch(`${BASE_URL}/${endpoint}`, {
    method: 'POST',
    body: JSON.stringify({ "ComplaintId": ID }),
    headers: {
      'Content-Type': 'application/json',
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const header = response.headers.get('Content-Disposition');
      const parts = header?.split(';');
      fileName = parts[1].split('=')[1];
      return response.blob();
    })
    .then((blob) => {
      // Create a URL for the Blob
      // debugger;
      var url = window.URL.createObjectURL(blob);

      // Create a temporary <a> element to trigger the download
      const a = document.createElement('a');
      a.href = url;
      const parts = url.split('/');
      url = url.replace(parts[parts.length - 1], ID);
      a.download = fileName; // Replace with the desired filename
      document.body.appendChild(a);
      a.setAttribute('target', '_blank');
      a.click();

      // Clean up resources
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      //this.setState({ loading: false });
    })
    .catch((error) => {
      console.error('There was a problem with the fetch operation:', error);
      //this.setState({ loading: false });
    });
};
