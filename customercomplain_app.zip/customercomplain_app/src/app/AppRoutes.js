import React, { Component, Suspense } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import Spinner from '../app/shared/Spinner';
import secureLocalStorage from 'react-secure-storage';


class AppRoutes extends Component {
  render() {
    let menuList = secureLocalStorage.getItem("MENU")
    return (
      <Suspense fallback={<Spinner />}>
        <Switch >
          {menuList?.length > 0 && menuList?.map((item) =>
            <Route exact key={item?.path} path={item?.path} component={item?.value} />)
          }
          <Redirect to="/dashboard" />
        </Switch>
      </Suspense>
    );
  }
}

export default AppRoutes;