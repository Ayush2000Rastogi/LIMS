import React, { Component } from 'react'
import { Button } from 'react-bootstrap';

export class PageLoader extends Component {
    render() {
        return (
            <div className="d-flex justify-content-center align-content-center" >
                {this.props?.error ?
                    <div className='card'>
                        <div class="card-body">
                            Something went wrong. Please Refresh page.
                        </div>
                        <div class="card-body text-center">
                            <Button variant="primary" size='sm' onClick={this.props?.refreshPage}>Retry
                            </Button>
                        </div>
                    </div>
                    :
                    <div className="spinner-border" role="status">
                        <span className="sr-only">Loading...</span>
                    </div>}
            </div>
        )
    }
}

export default PageLoader