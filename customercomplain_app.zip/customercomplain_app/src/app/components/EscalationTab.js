import React, { Component } from 'react';
import { get, post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import 'datatables.net';
import $ from 'jquery';
import { DeleteEscalationData, GetAssignments, GetEscalationsData, GetEscalationsDays, materialUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
import DeleteModal from '../form-elements/DeleteModal';
import Select from 'react-select';
import EscalationModal from '../form-elements/EscalationModal';
window.JSZip = JSZip;


class EscalationTab extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            materialList: [],
            departmentList: [],
            material: null,
            department: null,
            matEscalationDays: null,
            depEscalationDays: null,
            modalShow: false,
            deleteModalShow: false,
            type: '',
            selectedData: {},
            deletePayload: {},
            deleteUrl: '',
            isPNoModal: false,
        };
    }
    componentDidMount() {
        let options = {
            "paging": true,
            "bLengthChange": false,
            "pageLength": 4,
            "ordering": false,
            "info": false,
            "searching": false,
            "fixedHeader": true,
            data: [],
            destroy: true,
            responsive: true,
        }
        let commonColumns = [
            { title: 'PNO', data: 'PNO' },
            {
                title: '', data: null,
                render: function (data) {
                    return `<button type="button"  id='delete' class="btn btn-danger btn-sm ">Delete</button>`;
                }
            }
        ];
        var table1 = $('#ticket_assignment').DataTable({
            columns: [
                ...commonColumns
            ],
            ...options
        });
        var table2 = $('#ticket_assigned').DataTable({
            columns: [
                ...commonColumns
            ],
            ...options
        });
        this.BindMaterialList(materialUrl);
        this.BindDepartmentList(GetAssignments);
        this.BindEscalationDays(GetEscalationsDays);
    }


    componentWillUnmount() {
        const dataTable = $('#ticket_assignment').DataTable();
        dataTable.destroy();
        const natrTable = $('#ticket_assigned').DataTable();
        natrTable.destroy();
    }

    async BindMaterialList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                materialList: opt,
            });
        } catch (error) {
        }
    }
    async BindDepartmentList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                departmentList: opt,
            });
        } catch (error) {
        }
    }
    async BindEscalationDays(url) {
        try {
            var options = await get(url, {});
            for (var i = 0; i < options.d.length; i++) {
                if (options?.d[i]?.CODE === 'CC_ASGNMT')
                    this.setState({
                        matEscalationDays: options.d[i]?.VALUE,
                    });
                if (options?.d[i]?.CODE === 'CC_ASGND')
                    this.setState({
                        depEscalationDays: options.d[i]?.VALUE,
                    });
            }
        } catch (error) {
        }
    }

    async BindPnoList(url, param, name) {
        try {
            var options = await post(url, param);
            this.setState({ natureList: options.d });
            let tableName = name === 'material' ? '#ticket_assignment' : '#ticket_assigned'
            const dataTable = $(tableName).DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                if (e.target.id === 'delete') {
                    if (e.target.id === 'delete') {
                        let payload = {
                            "MATORDEPTID": data?.MATORDEPTID,
                            "PNO": data?.PNO
                        }
                        this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: DeleteEscalationData });
                    }
                }
            })
        } catch (error) {
        }
    }

    handleDialog = (isPNoModal, type) => {
        this.setState({ modalShow: true, type: type, isPNoModal: isPNoModal });
        if (isPNoModal && type === 'material')
            this.setState({ selectedData: { datList: this.state.materialList } });
        if (isPNoModal && type === 'department')
            this.setState({ selectedData: { datList: this.state.departmentList } });
        if (!isPNoModal)
            this.setState({ selectedData: { escalationDays: type === 'material' ? this.state.matEscalationDays : this.state.depEscalationDays } });
    }

    handleChange = (valueObj, name) => {
        if (valueObj?.value) {
            this.setState({
                [name]: valueObj?.value
            });
            let payload = {
                "MATORDEPTID": valueObj?.value
            }
            this.BindPnoList(GetEscalationsData, payload, name);
        }
    }

    render() {
        return (
            <>
                <div className="row pl-3">
                    <div className='col-md-6'>
                        <div className="ml-0 form-group row col-md-12 justify-content-between">
                            <h4 className="mb-4">Ticket Assignment</h4>
                            <div className={'ml-2'}>
                                <Button className={'btn btn-primary btn-sm '} disabled>Escalation Days : {this.state?.matEscalationDays}</Button>
                                <Button className={'btn btn-success btn-sm '} onClick={() => this.handleDialog(false, 'material')}>Edit</Button>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <div className="d-flex justify-content-between mb-2">
                                <div className='pl-0 form-group col-md-6'>
                                    <Select
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                        onChange={(valueObj) => this.handleChange(valueObj, 'material')}
                                        options={this.state.materialList}
                                        closeMenuOnSelect={true}
                                        hideSelectedOptions={false}
                                        placeholder={'Select Material'}
                                        isClearable={true}
                                    />
                                </div>
                                <div className="">
                                    <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog(true, 'material')}>Add P. No</Button>
                                </div>
                            </div>
                            <div className='pl-0 pr-0 col-md-12  table-responsive'>
                                <table className='table table-bordered' id="ticket_assignment" style={{ width: "100%" }}>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div className='col-md-6'>
                        <div className="ml-0 form-group row col-md-12 justify-content-between">
                            <h4 className="mb-4">Ticket Assigned (Escalate if CAPA not filled)</h4>
                            <div className={'ml-2'}>
                                <Button className={'btn btn-primary btn-sm '} disabled>Escalation Days : {this.state?.depEscalationDays}</Button>
                                <Button className={'btn btn-success btn-sm '} onClick={() => this.handleDialog(false, 'department')}>Edit</Button>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <div className="d-flex justify-content-between mb-2">
                                <div className='pl-0 form-group col-md-6'>
                                    <Select
                                        menuPortalTarget={document.body}
                                        styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                        onChange={(valueObj) => this.handleChange(valueObj, 'department')}
                                        options={this.state.departmentList}
                                        closeMenuOnSelect={true}
                                        hideSelectedOptions={false}
                                        placeholder={'Select Department'}
                                        isClearable={true}
                                    />
                                </div>
                                <div className="">
                                    <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog(true, 'department')}>Add P. No</Button>
                                </div>
                            </div>
                            <div className='pl-0 pr-0 col-md-12  table-responsive'>
                                <table className='table table-bordered' id="ticket_assigned" style={{ width: "100%" }}>
                                </table>
                            </div>
                        </div>
                    </div>
                </div >
                {
                    this.state.modalShow &&
                    <EscalationModal
                        modalShow={this.state.modalShow}
                        closeDialog={() => this.setState({ modalShow: false, isPNoModal: false, selectedData: {} })}
                        selectedData={this.state.selectedData}
                        type={this.state.type}
                        isPNoModal={this.state.isPNoModal}
                    />
                }
                {
                    this.state.deleteModalShow &&
                    <DeleteModal
                        modalShow={this.state.deleteModalShow}
                        closeDialog={() => this.setState({ deleteModalShow: false, selectedData: {} })}
                        payload={this.state.deletePayload}
                        URL={this.state.deleteUrl}
                    />
                }
            </>
        )
    }
}

export default EscalationTab;
