import React, { Component } from 'react';
import { post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net';
import $ from 'jquery';
import { GetAssignments, GetCategory, InsertUpdateDeleteAssignment, InsertUpdateDeleteCategory, InsertUpdateDeleteSubNature, natrUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import 'datatables.net-dt/css/jquery.dataTables.css';
import DepartmentModal from '../form-elements/DepartmentModal';
import DeleteModal from '../form-elements/DeleteModal';

class DepartmentTab extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            categoryList: [],
            assignmentsList: [],
            natureList: [],
            modalShow: false,
            deleteModalShow: false,
            dialogMode: 'add',
            type: '',
            selectedData: {},
            deletePayload: {},
            deleteUrl: ''
        };
    }
    componentDidMount() {
        let options = {
            "paging": true,
            "bLengthChange": false,
            "pageLength": 4,
            "ordering": false,
            "info": false,
            "searching": false,
            "fixedHeader": true,
            data: [],
            destroy: true,
            responsive: true,
        }
        var table1 = $('#assignTable').DataTable({
            columns: [
                { title: 'ID', data: 'ID', visible: false },
                { title: 'NAME', data: 'VAL' },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button" id='edit'  class="btn btn-success btn-sm ">Edit</button>`;
                    }
                },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button"  id='delete' class="btn btn-danger btn-sm ">Delete</button>`;
                    }
                }
            ],
            ...options
        });
        var table2 = $('#categoryTable').DataTable({
            columns: [
                { title: 'ID', data: 'ID', visible: false },
                { title: 'NAME', data: 'VALUE' },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button" id='edit' class="btn btn-success btn-sm ">Edit</button>`;
                    }
                },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button"  id='delete' class="btn btn-danger btn-sm ">Delete</button>`;
                    }
                }
            ],
            ...options
        });
        var table3 = $('#natrTable').DataTable({
            columns: [
                { title: 'ID', data: 'ID', visible: false },
                { title: 'NAME', data: 'VAL' },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button" id='edit' class="btn btn-success btn-sm ">Edit</button>`;
                    }
                },
                {
                    title: '', data: null,
                    render: function (data) {
                        return `<button type="button"  id='delete' class="btn btn-danger btn-sm ">Delete</button>`;
                    }
                }
            ],
            ...options
        });
        this.BindAssignments(GetAssignments, {});
        this.BindCategoryList(GetCategory, {});
        this.BindNature(natrUrl, {});
    }

    componentWillUnmount() {
        const dataTable = $('#assignTable').DataTable();
        dataTable.destroy();
        const natrTable = $('#natrTable').DataTable();
        natrTable.destroy();
        const categoryTable = $('#categoryTable').DataTable();
        categoryTable.destroy();
    }

    async BindAssignments(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ assignmentsList: options.d });
            const dataTable = $('#assignTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedData: { "ID": data?.ID, "VALUE": data?.VAL } })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', 'ASSIGNMENT')
                }
                if (e.target.id === 'delete') {
                    let payload ={
                        "TYPE": "DELETE",
                        "ASSIGNID": data?.ID,
                        "ASSIGNNAME": data?.VAL,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteAssignment });
                }
            });
        } catch (error) {
        }
    }

    async BindCategoryList(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ categoryList: options.d });
            const dataTable = $('#categoryTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedData: { "ID": data?.ID, "VALUE": data?.VALUE } })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', 'RANK')
                }
                if (e.target.id === 'delete') {
                    let payload ={
                        "TYPE": "DELETE",
                        "CATID": data?.ID,
                        "CATNAME": data?.VALUE,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteCategory });
                }
            });
        } catch (error) {
        }
    }

    async BindNature(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ natureList: options.d });
            const dataTable = $('#natrTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedData: { "ID": data?.ID, "VALUE": data?.VAL } })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', 'NATURE')
                }
                if (e.target.id === 'delete') {
                    if (e.target.id === 'delete') {
                        let payload ={
                            "TYPE": "DELETE",
                            "SUBNATID": data?.ID,
                            "SUBNATNAME": data?.VAL,
                            "USERNAME": this.state.USERNAME
                        }
                        this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteSubNature});
                    }
                }
            });
        } catch (error) {
        }
    }

    handleDialog = (mode, type) => {
        this.setState({ modalShow: true, dialogMode: mode, type: type });
    }

    render() {
        return (
            <div className="row mb-2" >
                <div className='col-md-6'>
                    <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                        <h6>Pending for Assignment</h6>
                        <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', 'ASSIGNMENT')}>Add Assignment</Button>
                    </div>
                    <div >
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="assignTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                </div>
                <div className=' col-md-6'>
                    <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                        <h6>Rank</h6>
                        <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', 'RANK')}>Add Rank</Button>
                    </div>
                    <div >
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="categoryTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                </div>
                <div className='col-md-6 mt-4'>
                    <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                        <h6>Nature</h6>
                        <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', 'NATURE')}>Add Nature</Button>
                    </div>
                    <div >
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="natrTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                </div>
                {this.state.modalShow &&
                    <DepartmentModal
                        modalShow={this.state.modalShow}
                        closeDialog={() => this.setState({ modalShow: false, dialogMode: 'add', selectedData: {} })}
                        dialogMode={this.state.dialogMode}
                        selectedData={this.state.selectedData}
                        type={this.state.type} />
                }
                {this.state.deleteModalShow &&
                    <DeleteModal
                        modalShow={this.state.deleteModalShow}
                        closeDialog={() => this.setState({ deleteModalShow: false, selectedData: {} })}
                        payload={this.state.deletePayload}
                        URL={this.state.deleteUrl}
                    />
                }
            </div >
        )
    }
}

export default DepartmentTab;
