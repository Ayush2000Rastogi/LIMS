import React, { Component } from 'react';
import { post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import 'datatables.net';
import $ from 'jquery';
import { materialUrl, gradeUrl, impactUrl, natureUrl, InsertUpdateDeleteMaterial, InsertUpdateDeleteNature, InsertUpdateDeleteImpact, InsertUpdateDeleteGrade } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import MaterialModal from '../form-elements/MaterialModal';
import DeleteModal from '../form-elements/DeleteModal';


class MaterialTab extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            materialList: [],
            natureList: [],
            gradeList: [],
            impactList: [],
            modalShow: false,
            deleteModalShow: false,
            dialogMode: 'add',
            isMaterialModal: false,
            selectedMaterial: {},
            deletePayload: {},
            deleteUrl: '',
            subType: 'NATURE',
            selectedMaterialData: {},
            isAddGradeVisible: true
        };
    }
    componentDidMount() {
        let options = {
            "paging": true,
            "bLengthChange": false,
            "pageLength": 4,
            "ordering": false,
            "info": false,
            "searching": false,
            "fixedHeader": true,
            data: [],
            destroy: true,
            responsive: true,
        }
        let commonColumns = [{ title: 'ID', data: 'ID', visible: false },
        { title: 'NAME', data: 'VAL' },
        {
            title: '', data: null,
            render: function (data) {
                return `<button type="button"  id="edit" class="btn btn-success btn-sm ">Edit</button>`;
            }
        },
        {
            title: '', data: null,
            render: function (data) {
                return `<button type="button" id="delete" class="btn btn-danger btn-sm ">Delete</button>`;
            }
        }]
        var table1 = $('#materialTable').DataTable({
            columns: [
                {
                    targets: 0,
                    searchable: false,
                    orderable: false,
                    render: function (data, type, full, meta) {
                        if (type === 'display') {
                            data = '<input type="radio" name="id" value="' + data + '">';
                        }

                        return data;
                    }
                },
                ...commonColumns
            ],
            ...options,
            select: true
        });
        var table2 = $('#natureTable').DataTable({
            columns: [
                ...commonColumns
            ],
            ...options
        });
        var table3 = $('#gradeTable').DataTable({
            columns: [
                ...commonColumns
            ],
            ...options
        });
        var table4 = $('#impactTable').DataTable({
            columns: [
                ...commonColumns
            ],
            ...options
        });
        this.BindMaterial(materialUrl, {});
    }

    componentWillUnmount() {
        const dataTable = $('#materialTable').DataTable();
        dataTable.destroy();
        const natrTable = $('#natureTable').DataTable();
        natrTable.destroy();
        const categoryTable = $('#gradeTable').DataTable();
        categoryTable.destroy();
        const impactTable = $('#impactTable').DataTable();
        impactTable.destroy();
    }

    handleDialog = (mode, modalType, subType) => {
        this.setState({ modalShow: true, dialogMode: mode, isMaterialModal: modalType, subType: subType });
    }

    async BindMaterial(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ materialList: options.d });
            const dataTable = $('#materialTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedMaterialData: { matID: data?.ID, matValue: data?.VAL }, selectedMaterial: data })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', true, '')
                }
                if (e.target.id === 'delete') {
                    let payload = {
                        "TYPE": "DELETE",
                        "MATID": data?.ID,
                        "MATNAME": data?.VAL,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteMaterial });
                }

            });
            dataTable.on('click', 'input', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedMaterialData: { matID: data?.ID, matValue: data?.VAL }, selectedMaterial: data })
                if (data?.ID) {
                    this.BindNature(natureUrl, { MATID: data?.ID });
                    if (data?.ID !== "FLUX" && data?.ID !== "PCI" && data?.ID !== "IMPORTED_CC") {
                        this.BindGrade(gradeUrl, { MATID: data?.ID });
                        this.setState({ isAddGradeVisible: true })
                    }
                    else {
                        const dataTable = $('#gradeTable').DataTable();
                        dataTable.clear();
                        dataTable.rows.add([]);
                        dataTable.draw();
                        this.setState({ isAddGradeVisible: false })
                    }
                    this.BindImpact(impactUrl, { MATID: data?.ID });
                }
            });
        } catch (error) {
        }
    }
    async BindNature(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ materialList: options.d });
            const dataTable = $('#natureTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedMaterial: { ...this.state.selectedMaterialData, ...data } })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', false, 'NATURE')
                }
                if (e.target.id === 'delete') {
                    let payload = {
                        "TYPE": "DELETE",
                        "MATID": this.state?.selectedMaterialData?.matID,
                        "NATID": data?.ID,
                        "NATNAME": data?.VAL,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteNature });
                }

            });
        } catch (error) {
            // this.setState({ error: true })
        }
    }
    async BindGrade(url, param) {
        try {
            var options = await post(url, param);

            this.setState({ materialList: options.d });
            const dataTable = $('#gradeTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedMaterial: { ...this.state.selectedMaterialData, ...data } })

                if (e.target.id === 'edit') {
                    this.handleDialog('edit', false, 'GRADE')
                }
                if (e.target.id === 'delete') {
                    let payload = {
                        "TYPE": "DELETE",
                        "MATID": this.state?.selectedMaterialData?.matID,
                        "GRADEID": data?.ID,
                        "GRADENAME": data?.VAL,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteGrade });
                }

            });
        } catch (error) {
        }
    }
    async BindImpact(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ materialList: options.d });
            const dataTable = $('#impactTable').DataTable();
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedMaterial: { ...this.state.selectedMaterialData, ...data } })

                if (e.target.id === 'edit') {
                    this.handleDialog('edit', false, 'IMPACT')
                }
                if (e.target.id === 'delete') {
                    let payload = {
                        "TYPE": "DELETE",
                        "MATID": this.state?.selectedMaterialData?.matID,
                        "IMPACTID": data?.ID,
                        "IMPACTNAME": data?.VAL,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteImpact });
                }
            });
        } catch (error) {
        }
    }

    render() {
        return (
            <div >
                <div className="row" >
                    <div className='col-md-6'>
                        <div className="pl-4 pr-4 d-flex justify-content-between mb-2 ">
                            <h6>Material</h6>
                            <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', true, '')}>Add Material</Button>
                        </div>
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="materialTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                    <div className='col-md-6'>
                        <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                            <h6>Nature</h6>
                            <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', false, 'NATURE')}>Add Nature</Button>
                        </div>
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="natureTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                    <div className='col-md-6 mt-4'>
                        <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                            <h6>Grade</h6>
                            {this.state.isAddGradeVisible &&
                                <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', false, 'GRADE')}>Add Grade</Button>}
                        </div>
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="gradeTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                    <div className='col-md-6 mt-4'>
                        <div className="pl-4 pr-4 d-flex justify-content-between mb-2">
                            <h6>Impact</h6>
                            <Button className={'btn btn-success btn-sm'} onClick={() => this.handleDialog('add', false, 'IMPACT')}>Add Impact</Button>
                        </div>
                        <div className='col-md-12  table-responsive'>
                            <table className='table table-bordered' id="impactTable" style={{ width: "100%" }}>
                            </table>
                        </div>
                    </div>
                </div>
                {this.state.modalShow &&
                    <MaterialModal
                        modalShow={this.state.modalShow}
                        closeDialog={() => this.setState({ modalShow: false, dialogMode: 'add', selectedMaterial: {} })}
                        isMaterialModal={this.state.isMaterialModal}
                        dialogMode={this.state.dialogMode}
                        selectedMaterial={this.state.selectedMaterial}
                        subType={this.state.subType}
                    />
                }
                {this.state.deleteModalShow &&
                    <DeleteModal
                        modalShow={this.state.deleteModalShow}
                        closeDialog={() => this.setState({ deleteModalShow: false, selectedMaterial: {} })}
                        payload={this.state.deletePayload}
                        URL={this.state.deleteUrl}
                    />
                }
            </div>
        )
    }
}

export default MaterialTab;
