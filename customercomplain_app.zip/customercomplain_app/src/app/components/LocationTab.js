import React, { Component } from 'react';
import { get } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import 'datatables.net';
import $ from 'jquery';
import { GetPlantsModify, InsertUpdateDeleteLocation, InsertUpdateDeleteSubLocation } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
import LocationModal from '../form-elements/LocationModal';
import DeleteModal from '../form-elements/DeleteModal';
window.JSZip = JSZip;


class LocationTab extends Component {
    constructor(props) {
        super(props);
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            actionList: [],
            btnLoading: false,
            selectedIndex: '',
            error: false,
            modalShow: false,
            deleteModalShow: false,
            isSubmitCAPA: false,
            dialogMode: 'add',
            isLocationModal: false,
            selectedLocation: {},
            deletePayload: {},
            deleteUrl: ''
        };
    }
    componentDidMount() {
        let options = {
            "paging": true,
            "bLengthChange": false,
            "pageLength": 7,
            "ordering": false,
            "info": false,
            "searching": true,
            "fixedHeader": true,
            data: [],
            destroy: true,
            responsive: true,
        }
        var table = $('#locTable').DataTable({
            columns: [
                {
                    title: 'Location', data: 'LOCNAME',
                    mRender: function (data, type, row) {
                        if (data)
                            return `${data}<span class='ml-2'></span><button id="editLocation" type="button" class="btn btn-success btn-sm" >Edit</button></>
                            <span class='ml-1'></span><button id="deleteLocation" type="button" class="btn btn-danger btn-sm">Delete</button></>`
                        else
                            return ''
                    }
                },
                { title: 'Plant', data: 'SUBLOCNAME', name: 'second' },
                {
                    data: "SUBLOCNAME",
                    mRender: function (data, type, row) {
                        if (data)
                            return '<button id="edit" type="button" class="btn btn-success btn-sm" >Edit</button>'
                        else
                            return ''
                    }
                },
                {
                    data: "SUBLOCNAME", mRender: function (data, type, row) {
                        if (data)
                            return '<button id="delete" type="button1" class="btn btn-danger btn-sm" >Delete</button>'
                        else
                            return ''
                    }
                },
            ],

            ...options
        });
        this.BindTableList(GetPlantsModify)

    }
    handleDialog = (mode, modalType) => {
        this.setState({ modalShow: true, dialogMode: mode, isLocationModal: modalType });
    }

    async BindTableList(url) {
        try {
            var options = await get(url);
            const dataTable = $('#locTable').DataTable();
            // if (Object.keys(options).length > 0) {
            //     this.setState({ loading: false });
            // }
            dataTable.clear();
            let id = ''
            let newData = options?.d?.map((item) => {
                if (id && id === item?.LOCID)
                    return { ...item, LOCNAME: '' }
                else {
                    id = item?.LOCID;
                    return { ...item }
                }
            })
            dataTable.rows.add(newData || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                this.setState({ selectedLocation: data })
                if (e.target.id === 'edit') {
                    this.handleDialog('edit', false)
                }
                if (e.target.id === 'delete') {
                    let payload = {
                        "TYPE": "DELETE",
                        "LOCID": data?.LOCID,
                        "SUBLOCID": data?.SUBLOCID,
                        "SUBLOCNAME": data?.SUBLOCNAME,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteSubLocation });
                }
                if (e.target.id === 'editLocation') {
                    this.handleDialog('edit', true)
                }
                if (e.target.id === 'deleteLocation') {
                    let payload = {
                        "TYPE": "DELETE",
                        "LOCID": data?.LOCID,
                        "LOCNAME": data?.LOCNAME,
                        "USERNAME": this.state.USERNAME
                    }
                    this.setState({ deleteModalShow: true, deletePayload: payload, deleteUrl: InsertUpdateDeleteLocation });
                }

            });
        } catch (error) {
            this.setState({ loading: false });
            this.setState({ error: true })
        }
    }

    componentWillUnmount() {

    }

    render() {
        return (
            <>
                <div>
                    <div className='col-md-12 d-flex justify-content-start mb-2'>
                        <Button className={' btn btn-success btn-sm'} onClick={() => this.handleDialog('add', true)}>{"Add New Location"}</Button>
                        <Button className={' btn btn-success btn-sm'} onClick={() => this.handleDialog('add', false)}>{"Add New Plant"}</Button>
                    </div>
                    <div className='col-md-12  table-responsive'>
                        <table className='table table-bordered' id="locTable" style={{ width: "100%" }}>
                        </table>
                    </div>
                </div>
                {this.state.modalShow &&
                    <LocationModal modalShow={this.state.modalShow} closeDialog={() => this.setState({ modalShow: false, dialogMode: 'add', selectedLocation: {} })} isLocationModal={this.state.isLocationModal} dialogMode={this.state.dialogMode} selectedLocation={this.state.selectedLocation} />
                }
                {this.state.deleteModalShow &&
                    <DeleteModal
                        modalShow={this.state.deleteModalShow}
                        closeDialog={() => this.setState({ deleteModalShow: false, selectedLocation: {} })}
                        payload={this.state.deletePayload}
                        URL={this.state.deleteUrl}
                    />
                }
            </>
        )
    }
}

export default LocationTab;
