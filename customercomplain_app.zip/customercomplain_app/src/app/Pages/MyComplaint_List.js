import React, { Component } from 'react';
import { post } from '../ApiMethod';
import Select from 'react-select';
import '../Pages/User_Complaint.css';
import 'datatables.net';
import $ from 'jquery';
import JSZip from 'jszip';
import { GetMyTicketList, gradeUrl, locationUrl, materialUrl, natureUrl, sublocationUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import 'datatables.net-dt/css/jquery.dataTables.css';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
import ComplaintUpdateModal from '../form-elements/ComplaintUpdateModal';

window.JSZip = JSZip;

class MyComplaint_List extends Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            error: false,
            gradeList: [],
            locationList: [],
            materialList: [],
            plantList: [],
            natureList: [],
            location: null,
            plant: null, grade: null, nature: null, material: null,
            fromDate: "",
            toDate: new Date().toISOString().split('T')[0],
            tableShow: false,
            modalShow: false,
            selectedData: {},
        };
    }

    componentDidMount() {
        var table = $('#example').DataTable({
            dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
                "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            buttons: [{
                extend: 'excel',
                text: 'Export',
                filename: `data_${new Date().toISOString().split('T')[0]}`,
                className: 'btn btn-success btn-sm',
                exportOptions: {
                    columns: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
                },
            }],
            drawCallback: function () {
                var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
                $('.buttons-excel')[0].style.visibility = hasRows ? 'visible' : 'hidden'
            },
            columns: [
                { title: 'Complaint No.', data: 'ID' },
                { title: 'Location', data: 'LOCATION' },
                { title: 'Plant', data: 'PLANT' },
                { title: 'Material', data: 'MATERIAL' },
                { title: 'Nature', data: 'NATURE' },
                { title: 'Grade', data: 'GRADE' },
                { title: 'Impact', data: 'IMPACT' },
                { title: 'Rank', data: 'RANK' },
                {
                    title: 'Description', data: 'DESCRIPTION',
                    render: function (data) {
                        let descValue = data?.replace(/<[^>]+>/g, '');
                        return descValue || "-";
                    }
                },
                { title: 'Date of Logging', data: 'LOGGED_DATE' },
                { title: 'Status', data: 'CURRENTSTATUS' },
                { title: 'Remark', data: 'RW_REMARK' },
                {
                    data: "CURRENTSTATUS", mRender: function (data, type, row) {
                        if (data === 'Returned With Remark')
                            return `<button type="button" id='edit' class="btn btn-success btn-sm">Edit</button>`;
                        else
                            return ''
                    }
                },
            ],
            data: [],
            destroy: true,
            responsive: true,
            'rowsGroup': [0, 1],
            "paging": true,
            "bLengthChange": false,
            "pageLength": 7,
            "ordering": false,
            "info": false,
            "searching": true,
            "scrollX": true,
            "fixedHeader": true,

        });
        table.buttons().container()
            .appendTo('#example_wrapper .col-md-6:eq(0)');
        this.BindLocationList(locationUrl);
        this.BindMaterialList(materialUrl);
    }

    componentWillUnmount() {
        const dataTable = $('#example').DataTable();
        dataTable.destroy();
    }

    async BindLocationList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                locationList: opt,
            });
        } catch (error) {
        }
    }

    async BindMaterialList(url) {
        try {
            var options = await post(url, {});
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                materialList: opt,
            });
        } catch (error) {
        }
    }

    async BindGradeDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                gradeList: opt,
            });
        } catch (error) {
        }
    }

    async BindNatureDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                natureList: opt,
            });
        } catch (error) {
            // Handle errors
        }
    }

    async BindPlantDDL(url, param) {
        try {
            var options = await post(url, param);
            var opt = [];
            for (var i = 0; i < options.d.length; i++) {
                opt.push(
                    { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
                )
            }
            this.setState({
                plantList: opt,
            });
        } catch (error) {
        }
    }


    async BindTableList(url, param) {
        try {
            var options = await post(url, param);
            const dataTable = $('#example').DataTable();
            if (Object.keys(options).length > 0) {
                this.setState({ loading: false });
            }
            dataTable.clear();
            dataTable.rows.add(options?.d || []);
            dataTable.draw();
            dataTable.on('click', 'button', (e) => {
                let data = dataTable.row(e.target.closest('tr')).data();
                if (e.target.id === 'edit') {
                    this.setState({ modalShow: true, selectedData: data })
                }
            });

        } catch (error) {
            this.setState({ loading: false });
            this.setState({ error: true })
        }
    }


    handleChange = (valueObj, name) => {
        this.setState({ [name]: valueObj?.value || null })
        if (name === 'location') {
            if (valueObj?.value) {
                this.BindPlantDDL(sublocationUrl, { LOCID: valueObj?.value });
            }
            else {
                this.setState({
                    plantList: [],
                });
            }
        }
        if (name === 'material') {
            if (valueObj?.value) {
                this.BindNatureDDL(natureUrl, { MATID: valueObj.value });
                this.BindGradeDDL(gradeUrl, { MATID: valueObj.value });
            }
            else {
                this.setState({
                    natureList: [],
                    gradeList: [],
                });
            }
        }
    }

    handleDateValueChange = (event, name) => {
        this.setState({ [name]: event.target.value })
    }


    onSearchClick = () => {
        let payload = {
            "FROM_DATE": this.state.fromDate,
            "TO_DATE": this.state.toDate,
            "LOCATION": this.state.location,
            "PLANT": this.state.plant,
            "MATERIAL": this.state.material,
            "GRADE": this.state.grade,
            "NATURE": this.state.nature,
            "USERNAME": this.state.USERNAME
        }
        this.BindTableList(GetMyTicketList,
            payload)
        this.setState({ loading: true });
        this.setState({ tableShow: true })
    }

    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>My Complaints</h3>
                </div>

                <div className="row pl-3">
                    <div className="col-md-3 col-lg-2 p-1">
                        <div className='form-group'>
                            <Select
                                menuPortalTarget={document.body}
                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                onChange={(valueObj) => this.handleChange(valueObj, 'location')}
                                options={this.state.locationList}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                placeholder={'Select Location'}
                                isClearable={true}
                            />
                        </div>
                    </div>
                    <div className="col-md-3 col-lg-2 p-1">
                        <div className='form-group'>
                            <Select
                                menuPortalTarget={document.body}
                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                onChange={(valueObj) => this.handleChange(valueObj, 'plant')}
                                options={this.state.plantList}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                placeholder={'Select Plant'}
                                isClearable={true}
                            />
                        </div>
                    </div>
                    <div className="col-md-3 col-lg-2 p-1">
                        <div className='form-group'>
                            <Select
                                menuPortalTarget={document.body}
                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                onChange={(valueObj) => this.handleChange(valueObj, 'material')}
                                options={this.state.materialList}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                placeholder={'Select Material'}
                                isClearable={true}
                            />
                        </div>
                    </div>
                    <div className="col-md-3 col-lg-2 p-1">
                        <div className='form-group'>
                            <Select
                                menuPortalTarget={document.body}
                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                onChange={(valueObj) => this.handleChange(valueObj, 'nature')}
                                options={this.state.natureList}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                placeholder={'Select Nature'}
                                isClearable={true}
                            />
                        </div>
                    </div>
                    <div className="col-md-3 col-lg-2 p-1">
                        <div className='form-group'>
                            <Select
                                menuPortalTarget={document.body}
                                styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                                onChange={(valueObj) => this.handleChange(valueObj, 'grade')}
                                options={this.state.gradeList}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                placeholder={'Select Grade'}
                                isClearable={true}
                            />
                        </div>
                    </div>
                </div>
                <div className="row mb-3">
                    <div className="col-md-3 col-lg-3 col-xl-3 d-flex align-items-center">
                        <label className="mr-2">From:</label>
                        <input
                            type="date"
                            max={new Date().toISOString().split('T')[0]}
                            defaultValue={this.state.fromDate}
                            className="form-control"
                            onChange={(event) => this.handleDateValueChange(event, 'fromDate')} />
                    </div>
                    <div className="flex mt-auto mb-3">
                        <i className="mdi mdi-arrow-right"></i>
                    </div>
                    <div className="col-md-3 col-lg-3 col-xl-3 d-flex align-items-center">
                        <label className="mr-2">To:</label>
                        <input
                            type="date"
                            min={this.state.fromDate}
                            max={new Date().toISOString().split('T')[0]}
                            defaultValue={this.state.toDate}
                            className="form-control"
                            onChange={(event) => this.handleDateValueChange(event, 'toDate')} />
                    </div>
                    <div className="col-md-3 col-lg-2 d-flex align-items-center">
                        <Button className={'w-80 btn btn-success btn-sm'}
                            disabled={!(this.state.fromDate && this.state.toDate)}
                            onClick={() => this.onSearchClick()}>Search
                            {this.state.loading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                        </Button>
                    </div>
                </div>
                <div >
                    <div className='col-md-12  table-responsive  mt-5'>
                        <table className='table table-bordered' id="example" style={{ width: "100%" }}>
                        </table>
                    </div>
                </div>
                {this.state.modalShow &&
                    <ComplaintUpdateModal
                        modalShow={this.state.modalShow}
                        closeDialog={() => this.setState({ modalShow: false, selectedData: {} })}
                        materialList={this.state.materialList}
                        locationList={this.state.locationList}
                        selectedData={this.state.selectedData}
                    />
                }
            </div>
        )
    }
}

export default MyComplaint_List;
