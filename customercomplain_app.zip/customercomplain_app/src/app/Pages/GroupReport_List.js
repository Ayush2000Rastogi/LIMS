import React, { Component } from 'react';
import { get } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import 'datatables.net';
import $ from 'jquery';
import { GetGroups } from '../Constant';
import secureLocalStorage from 'react-secure-storage';
import PageLoader from '../basic-ui/PageLoader';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
window.JSZip = JSZip;

class GroupReport_List extends Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            dataList: [],
            error: false
        };
    }
    componentDidMount() {
        this.BindList(GetGroups);
    }

    componentWillUnmount() {
        const dataTable = $(this.tableRef.current).DataTable();
        dataTable.destroy();
    }

    async BindList(url, param) {
        try {
            var options = await get(url);
            this.setState({ dataList: options.d });
            this.setState({ loading: true });
            let table = $(this.tableRef.current).DataTable(
                {
                    dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    buttons: [{
                        extend: 'excel',
                        text: 'Export',
                        filename: `data_${new Date().toISOString().split('T')[0]}`,
                        className: 'btn btn-success btn-sm',
                    }],
                    drawCallback: function () {
                        var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
                        $('.buttons-excel')[0].style.visibility = hasRows ? 'visible' : 'hidden'
                    },
                    orderCellsTop: true,
                    initComplete: function () {
                        var table = this.api();
                        table.columns([2]).every(function (colIdx) {
                            var column = this;
                            var input = $('<input id="input"  type="text" style="padding:4px; border:1px solid" placeholder="Search by Date" />')
                                .appendTo($("thead tr:eq(1) td").eq(this.index()))
                                .off('keyup change')
                                .on('change', function (e) {
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})';
                                    column
                                        .column(colIdx)
                                        .search(
                                            this.value !== ''
                                                ? regexr.replace('{search}', '(((' + this.value + ')))')
                                                : '',
                                            this.value !== '',
                                            this.value === ''
                                        )
                                        .draw();
                                })
                                .on('keyup', function (e) {
                                    e.stopPropagation();
                                    $(this).trigger('change');
                                });
                        });
                        table.columns([3, 4]).every(function () {
                            var column = this;
                            var select = $('<select style="padding:4px"><option value="">Please Select</option></select>')
                                .appendTo($("thead tr:eq(1) td").eq(this.index()))
                                .on('change', function () {
                                    var val = $.fn.dataTable.util.escapeRegex(
                                        $(this).val()
                                    );
                                    column
                                        .search(val ? '^' + val + '$' : '', true, false)
                                        .draw();
                                });

                            column.data().unique().sort().each(function (d, j) {
                                select.append('<option value="' + d + '">' + d + '</option>')
                            });
                        });
                    },
                    'destroy': true,
                    'rowsGroup': [0, 1],
                    'responsive': true,
                    "paging": true,
                    "bLengthChange": false,
                    "pageLength": 12,
                    "ordering": false,
                    "info": false,
                    "searching": true,
                    "scrollX": true,
                }
            ).columns.adjust();
            // Handle the data
        } catch (error) {
            this.setState({ error: true })
            // Handle errors
        }
    }

    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>Group Complaints Report</h3>
                </div>
                <div className=''>
                    <div className='col-md-12  table-responsive"'>
                        {this.state.loading ? (
                            <table className='table table-bordered' ref={this.tableRef} style={{ width: "100%" }}>
                                <thead>
                                    <tr>
                                        <th>Group Id</th>
                                        <th>Complaint No.</th>
                                        <th>Date of Logging</th>
                                        <th >Plant</th>
                                        <th>Material</th>
                                        <th>Nature</th>
                                        <th>Remarks</th>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state?.dataList?.map((item, index) => {
                                        let remarksValue = item["REMARK"]?.replace(/<[^>]+>/g, '');
                                        return <tr key={index}>
                                            <td>{item["GROUPID"]}</td>
                                            <td>{item["COMPLAINTID"]}</td>
                                            <td>{item["DT"]}</td>
                                            <td>{item["PLANTNAME"]}</td>
                                            <td>{item["MATERIALNAME"]}</td>
                                            <td>{item["NATURENAME"]}</td>
                                            <td>{remarksValue}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        ) : (
                            <PageLoader error={this.state.error} refreshPage={() => this.BindList(GetGroups)} />
                        )}
                    </div>
                </div>
            </div>
        )
    }
}

export default GroupReport_List;
