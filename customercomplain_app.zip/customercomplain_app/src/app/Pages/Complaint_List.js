import React, { Component } from 'react';
import {
  complaintnatureUrl, downloadUrl, GetComplainturl,
  insertAssignurl, materialUrl, natureUrl, natrUrl, GetAssignments, GetCategory, ReturnOrRejectTicket
} from '../Constant';
import { downloadFile, post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import Swal from 'sweetalert2';
import 'datatables.net';
import $ from 'jquery';
import { Button, Modal } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import PageLoader from '../basic-ui/PageLoader';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
import '../form-elements/Modal.css';
window.JSZip = JSZip;

class Complaint_List extends Component {
  constructor(props) {
    super(props);
    this.tableRef = React.createRef();
    let UserName = secureLocalStorage.getItem("USERID")
    this.state = {
      complaintList: [],
      selAction: [],
      selPending: [],
      selClosed: [],
      loading: false,
      USERNAME: UserName,
      natrList: [],
      materialList: [],
      btnLoading: false,
      selectedIndex: '',
      error: false,
      actionList: [
        { value: "A", label: "Accept" },
        { value: "R", label: "Return With Remark" },
        { value: "C", label: "Reject" },
      ],
      closedList: [],
      pendingList: [],
      modalShow: false,
      remarks: null,
    }
  }

  handleAcitonChange = (index, event) => {
    let lst = [...this.state.complaintList];
    lst[index]["ACTION"] = event.target.value;
    let actionFlag = event.target.value;
    if (actionFlag === 'R' || actionFlag === 'C') {
      lst[index]["isReturnWR"] = true;
    }
    else {
      lst[index]["isReturnWR"] = false;
    }
    this.setState({ complaintList: lst });
    this.setState({ selAction: event });
  }

  handlePendingChange = (index, event) => {
    let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
    lst[index]["PENDING"] = event.target.value;
    this.setState({ complaintList: lst });
    this.setState({ selPending: event });
  }

  handleClosedChange = (index, event) => {
    let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
    lst[index]["CLOSED"] = event.target.value;
    this.setState({ complaintList: lst });
    this.setState({ selClosed: event });
  }
  handleNatrChange = (index, event) => {
    let lst = [...this.state.complaintList];
    lst[index]["TNATURE"] = event.target.value;
    this.setState({ complaintList: lst });
  }

  checkBtnDisabled = (item) => {
    let objData = item
    if (!item["isReturnWR"] && objData?.ID && objData?.MATERIALID && objData?.NATURE &&
      objData?.TNATURE && objData?.ACTION && objData?.ACTION !== 'RA' && objData?.PENDING &&
      objData?.CLOSED && objData?.COMPLAINTASSIGN)
      return false
    else if (item["isReturnWR"])
      return false
    else return true
  }

  componentDidMount() {
    this.BindComplaintDDL(GetComplainturl);
    this.BindImpactDDL(materialUrl);
    this.BindNatrDDL(natrUrl);
    this.BindCategoryDDL(GetCategory);
    this.BindDepartmentDDL(GetAssignments);

  }
  handleMaterialChange(index, event) {
    let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
    lst[index]["MATERIALID"] = event.target.value;
    this.setState({ complaintList: lst });
    this.BindNatureDDL(natureUrl, { MATID: event.target.value }, index);
  }
  handleNatureChange(index, event) {
    let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
    lst[index]["NATUREID"] = event.target.value;
    this.setState({ complaintList: lst });
  }

  handleAssignChange(index, event) {
    let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
    lst[index]["COMPLAINTASSIGN"] = event.target.value;
    this.setState({ complaintList: lst });
  }

  async BindNatrDDL(url, param) {
    try {
      var options = await post(url, param);
      this.setState({ natrList: options.d });
    } catch (error) {
    }
  }

  async BindCategoryDDL(url, param) {
    try {
      var options = await post(url, param);
      this.setState({ closedList: options.d });
    } catch (error) {
    }
  }

  async BindDepartmentDDL(url, param) {

    try {
      var options = await post(url, param);
      this.setState({ pendingList: options.d });
    } catch (error) {
    }
  }

  async BindImpactDDL(url, param) {
    try {
      var options = await post(url, param);
      this.setState({ materialList: options.d });
    } catch (error) {
    }
  }

  async BindComplainNatureDDL(url, param) {
    try {
      var options = await post(url, param);
      return options.d;
    } catch (error) {
    }
  }

  async BindNatureDDL(url, param, index) {
    try {
      var options = await post(url, param);
      let lst = [...this.state.complaintList];     //or this.state.month.slice(0)
      lst[index]["NATURELIST"] = options.d;
      this.setState({ complaintList: lst });
    } catch (error) {
    }
  }

  componentWillUnmount() {
    const dataTable = $(this.tableRef.current).DataTable();
    dataTable.destroy();
  }

  async BindComplaintDDL(url, param) {
    try {
      var options = await post(url, param);
      this.setState({ complaintList: options.d });
      let lst = [...this.state.complaintList];
      lst = lst.map((item) => {
        if (item?.ACTION === 'R' || item?.ACTION === 'C') {
          item = { ...item, "isReturnWR": true }
        }
        else {
          item = { ...item, "isReturnWR": false }
        }
        return item
      })
      for (var i = 0; i < lst.length; i++) {
        lst[i]["NATURELIST"] = await this.BindComplainNatureDDL(complaintnatureUrl, { ID: lst[i]["ID"] });
      }
      this.setState({ complaintList: lst });
      this.setState({ loading: true });
      $(this.tableRef.current).DataTable(
        {
          dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
            "<'row'<'col-sm-12'tr>>" +
            "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
          buttons: [{
            extend: 'excel',
            text: 'Export',
            filename: `data_${new Date().toISOString().split('T')[0]}`,
            className: 'btn btn-success btn-sm',
            exportOptions: {
              format: {
                body: function (data, row, column, node) {
                  if ([3, 4].includes(column)) {
                    let finaldata = $(data).find("option:selected").text()
                    if (finaldata)
                      return finaldata
                    else
                      return ""
                  }
                  else return data
                }
              },
              columns: [0, 1, 2, 3, 4, 5, 6]
            },
          }],
          drawCallback: function () {
            var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
            $('.buttons-excel')[0].style.visibility = hasRows ? 'visible' : 'hidden'
          },
          'destroy': true,
          'rowsGroup': [0, 1],
          'responsive': true,
          "paging": true,
          "bLengthChange": false,
          "pageLength": 7,
          "ordering": false,
          "info": false,
          "searching": true,
          "scrollX": true,
        }
      );
    } catch (error) {
      this.setState({ error: true })
    }
  }

  onRegister = (index) => {
    this.setState({ selectedIndex: index })
    let actionFlag = this.state.complaintList[index]["ACTION"];
    if (actionFlag === 'R' || actionFlag === 'C') {
      this.setState({ modalShow: true, remarks: null });
    }
    else {
      this.submitData(index, insertAssignurl)
    }
  }

  handleSubmit = () => {
    this.handleClose()
    this.submitData(this.state.selectedIndex, ReturnOrRejectTicket)
  }

  submitData = (index, url) => {
    this.setState({ btnLoading: true })
    var data = {
      COMPLAINTID: this.state.complaintList[index]["ID"],
      MATID: this.state.complaintList[index]["MATERIALID"],
      NATUREID: this.state.complaintList[index]["NATUREID"],
      NATRID: this.state.complaintList[index]["TNATURE"],
      ACTION: this.state.complaintList[index]["ACTION"],
      PENDING: this.state.complaintList[index]["PENDING"],
      CLOSED: this.state.complaintList[index]["CLOSED"],
      ASSIGN: this.state.complaintList[index]["COMPLAINTASSIGN"],
      DESCRIPTION: this.state.complaintList[index]["REMARKS"],
      INITIATOR: this.state.complaintList[index]["INITIATOR"],
      REMARK: this.state.remarks,
      USERNAME: this.state.USERNAME
    }
    this.insertComplaint(url, data);
  }

  async insertComplaint(url, param) {
    try {
      var options = await post(url, param);
      if (options["Massage"]) { this.setState({ btnLoading: false, selectedIndex: '' }) }
      Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
      });
    } catch (error) {
      this.setState({ btnLoading: false, selectedIndex: '' })
      Swal.fire("", "Error", 'error');
    }
  }

  onDownload = (id) => {
    downloadFile(downloadUrl, id);
  }

  handleRemarkValueChange = (event, name) => {
    this.setState({ [name]: event.target.value })
  }

  handleClose = (event) => {
    this.setState({ modalShow: false, remarks: null })
  };

  render() {
    return (
      <div>
        <div>
          <div className="proBanner">
          </div>
          <div className="page-header">
            <h3 className="page-title">
              <span className="page-title-icon bg-gradient-primary text-white mr-2">
                <i className="mdi mdi-account-convert"></i>
              </span>Ticket Assignment </h3>
          </div>
          <div className='wrapper'>
            <div className='col-md-12  table-responsive"'>
              {this.state.loading ? (
                <table className='table table-bordered' ref={this.tableRef} style={{ width: "100%" }}>
                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Date</th>
                      <th>Plant</th>
                      <th>Material</th>
                      <th >Nature</th>
                      <th>Description</th>
                      <th>Impact</th>
                      <th>Attchment</th>
                      <th>Case loggend by</th>
                      <th>Name</th>
                      <th style={{ width: "150px " }}>Action</th>
                      <th style={{ width: "250px" }}>Department</th>
                      <th>Assigned</th>
                      <th style={{ width: "150px" }}>Rank</th>
                      <th style={{ width: "150px" }}>Nature</th>
                      <th></th>
                      {/* Add more columns as needed */}
                    </tr>
                  </thead>
                  <tbody>
                    {this.state?.complaintList?.map((item, index) => {
                      let isBtnDisabled = this.checkBtnDisabled(item)
                      let btnName = item["isReturnWR"] ? (item["ACTION"] === 'R' ? "Return" : "Reject") : "Assign";
                      return <tr key={index}>
                        <td>{item["ID"]}</td>
                        <td>{item["DT"]}</td>
                        <td>{item["PLANT"]}</td>
                        <td>
                          <select className='form-control' disabled={item["isReturnWR"]} defaultValue={item["MATERIALID"]} name={"MATERIALID_" + index.toString()} onChange={this.handleMaterialChange.bind(this, index)}>
                            <option key="0" value="">Please Select</option>
                            {this.state.materialList.map((option) => (
                              <option key={option.ID} value={option.ID} selected={option.ID === item["MATERIALID"] ? true : false}>
                                {option.VAL}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td><select className='form-control' disabled={item["isReturnWR"]} defaultValue={item["NATUREID"]} name={"NATURE" + index.toString()} onChange={this.handleNatureChange.bind(this, index)}>
                          <option key="0" value="">Please Select</option>
                          {this.state?.complaintList[index]["NATURELIST"]?.map((option) => (
                            <option key={option.ID} value={option.ID} selected={option.ID === item["NATUREID"] ? true : false}>
                              {option.VAL}
                            </option>
                          ))}
                        </select></td>
                        <td style={{ whiteSpace: "break-spaces" }}><span dangerouslySetInnerHTML={{ __html: item["REMARKS"] }} /></td>
                        <td>{item["IMPACT"]}</td>
                        <td style={{ textAlign: "center" }}>
                          {item["ATTACH"] === "1" &&
                            <h1><i role="button" className="mdi mdi-file-import icon" onClick={this.onDownload.bind(this, item["ID"])}></i></h1>
                          }
                        </td>
                        <td>{item?.CASELOGGEDBY}</td>
                        <td>{item?.CASELOGGEDBYNAME}</td>
                        <td>
                          <select className='form-control' defaultValue={item["ACTION"]} name={"ACTION" + index.toString()} onChange={this.handleAcitonChange.bind(this, index)}>
                            <option key="0" value="">Please Select</option>
                            {this.state.actionList.map((option) => (
                              <option key={option.value} value={option.value} selected={option.value === item["ACTION"] ? true : false}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <select className='form-control' disabled={item["isReturnWR"]} defaultValue={item["PENDING"]} name={"PENDING" + index.toString()} onChange={this.handlePendingChange.bind(this, index)}>
                            <option key="0" value="">Please Select</option>
                            {this.state.pendingList.map((option) => (
                              <option key={option.ID} value={option.ID} selected={option.ID === item["PENDING"] ? true : false}>
                                {option.VAL}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <input type="text" disabled={item["isReturnWR"]} maxLength="20" onChange={this.handleAssignChange.bind(this, index)} className='form-control Txt' defaultValue={item["COMPLAINTASSIGN"]}></input>
                        </td>
                        <td>
                          <select className='form-control' disabled={item["isReturnWR"]} defaultValue={item["CLOSED"]} name={"CLOSED" + index.toString()} onChange={this.handleClosedChange.bind(this, index)}>
                            <option key="0" value="">Please Select</option>
                            {this.state.closedList.map((option) => (
                              <option key={option.ID} value={option.ID} selected={option.ID === item["CLOSED"] ? true : false}>
                                {option.VALUE}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td>
                          <select className='form-control' disabled={item["isReturnWR"]} defaultValue={item["TNATURE"]} name={"TNATURE" + index.toString()} onChange={this.handleNatrChange.bind(this, index)}>
                            <option key="0" value="">Please Select</option>
                            {this.state?.natrList?.map((option) => (
                              <option key={option.ID} value={option.ID} selected={option.ID === item["TNATURE"] ? true : false}>
                                {option.VAL}
                              </option>
                            ))}
                          </select>
                        </td>
                        <td><Button className={isBtnDisabled ? 'btn btn-success  btn-sm disabled not-allowed' : 'btn btn-success btn-sm'} disabled={isBtnDisabled} onClick={this.onRegister.bind(this, index)}>{btnName}
                          {this.state.btnLoading && this.state.selectedIndex === index && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                        </Button></td>

                      </tr>
                    })}
                  </tbody>
                </table>
              ) : (
                <PageLoader error={this.state.error} refreshPage={() => {
                  this.BindComplaintDDL(GetComplainturl);
                  this.BindImpactDDL(materialUrl);
                  this.BindNatrDDL(natrUrl);
                }} />
              )}
            </div>
          </div>
        </div>
        {this.state.modalShow && <Modal show={this.state.modalShow}
          onHide={this.handleClose}
          centered
          className="my-modal"
          backdrop="static"
          keyboard={false}>
          <Modal.Header closeButton >
            <Modal.Title>Add Remarks</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <form>
              <div className="row mb-2">
                <div className="col-md-5">
                  <label><span className='required'>*</span>Remarks</label>
                </div>
                <div className="col-md-7 ml-auto">
                  <textarea
                    className="form-control"
                    id="field1" rows="3"
                    defaultValue={this.state.abnormality}
                    placeholder='Add remarks'
                    maxLength={'4000'}
                    onChange={(event) => this.handleRemarkValueChange(event, 'remarks')}></textarea>
                </div>
              </div>
            </form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={this.handleClose}>
              Cancel
            </Button>
            <Button variant="primary" onClick={this.handleSubmit}
              className={'btn'} >
              Submit
              {this.state.btnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
            </Button>
          </Modal.Footer>
        </Modal >}
      </div>
    )
  }
}

export default Complaint_List;





