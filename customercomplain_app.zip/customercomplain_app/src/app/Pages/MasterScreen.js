import React, { Component } from 'react';
import '../Pages/User_Complaint.css';
import { Tab, Tabs } from 'react-bootstrap';
import DepartmentTab from '../components/DepartmentTab';
import MaterialTab from '../components/MaterialTab';
import LocationTab from '../components/LocationTab';
import EscalationTab from '../components/EscalationTab';


class MasterScreen extends Component {
    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>Master List </h3>
                </div>
                <div className=''>
                    <div className='col-md-12  table-responsive"'>
                        <Tabs
                            defaultActiveKey="0"
                            id="uncontrolled-tab-example"
                            className="mb-3"
                        >
                            <Tab eventKey="0" title="Master for Location & Plant">
                                <LocationTab />
                            </Tab>
                            <Tab eventKey="1" title="Master for Material, Nature, Grade, Impact">
                                <MaterialTab />
                            </Tab>
                            <Tab eventKey="2" title="Master for Pending for Assignment, Rank, Nature" >
                                <DepartmentTab />
                            </Tab>
                            <Tab eventKey="3" title="Escalation" >
                                <EscalationTab />
                            </Tab>
                        </Tabs>
                    </div>
                </div>
            </div>
        )
    }
}

export default MasterScreen;
