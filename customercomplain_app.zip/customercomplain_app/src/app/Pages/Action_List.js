import React, { Component } from 'react';
import { post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import Swal from 'sweetalert2';
import 'datatables.net';
import $ from 'jquery';
import { GetActionsUrl, SaveActionListUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import PageLoader from '../basic-ui/PageLoader';
import ComplaintModal from '../form-elements/ComplaintModal';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
window.JSZip = JSZip;

class Action_List extends Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            actions: [
                { value: "ACCEPT", label: "Accept" },
                // { value: "RETURN", label: "Return" },
            ],
            USERNAME: UserName,
            actionList: [],
            btnLoading: false,
            selectedIndex: '',
            error: false,
            modalShow: false,
            isSubmitCAPA: false,
        };
    }
    componentDidMount() {
        this.BindActionList(GetActionsUrl, { "USERNAME": this.state.USERNAME });
    }

    componentWillUnmount() {
        const dataTable = $(this.tableRef.current).DataTable();
        dataTable.destroy();
    }

    async BindActionList(url, param) {
        try {
            var options = await post(url, param);
            this.setState({ actionList: options.d });
            this.setState({ loading: true });
            $(this.tableRef.current).DataTable(
                {
                    dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    buttons: [{
                        extend: 'excel',
                        text: 'Export',
                        filename: `data_${new Date().toISOString().split('T')[0]}`,
                        className: 'btn btn-success btn-sm',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6]
                        },
                    }],
                    drawCallback: function () {
                        var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
                        $('.buttons-excel')[0].style.visibility = hasRows ? 'visible' : 'hidden'
                    },
                    destroy: true,
                    'rowsGroup': [0, 1],
                    responsive: true,
                    "paging": true,
                    "bLengthChange": false,
                    "pageLength": 7,
                    "ordering": false,
                    "info": false,
                    "searching": true,
                    "scrollX": true,
                    "fixedHeader": true,
                    "fixedColumns": {
                        leftColumns: 2
                    }
                }
            );
        } catch (error) {
            this.setState({ error: true })
        }
    }


    handleActionChange = (index, event) => {
        let lst = [...this.state.actionList];     //or this.state.month.slice(0)
        lst[index]["ACTION"] = event.target.value;
        this.setState({ actionList: lst });
    }

    handleDescChange = (index, event) => {
        let lst = [...this.state.actionList];     //or this.state.month.slice(0)
        lst[index]["DESCRIPTION"] = event.target.value;
        this.setState({ actionList: lst });
    }

    handleRemarkChange(index, event) {
        let lst = [...this.state.actionList];     //or this.state.month.slice(0)
        lst[index]["REMARK"] = event.target.value;
        lst[index]["TCWI_REMARKS"] = event.target.value;
        this.setState({ actionList: lst });
    }

    checkBtnDisabled = (item) => {
        let objData = item
        if (objData?.TCWI_REMARKS && objData?.DESCRIPTION)
            return false
        else
            return true
    }

    handleSubmit = (flag) => {
        if (flag) {
            this.onRegister()
        }
    }

    onRegister = () => {
        let index = this.state.selectedIndex
        var data = {
            COMPLAINTID: this.state.actionList[index]["COMPLAINTNO"],
            ACTION: "ACCEPT",
            REMARK: this.state.actionList[index]["TCWI_REMARKS"],
            DESCRIPTION: this.state.actionList[index]["DESCRIPTION"],
            ASSIGN: this.state.USERNAME,
            USERNAME: this.state.USERNAME,
            INITIATOR: this.state.actionList[index]["INITIATOR"]
        }
        this.submitAction(SaveActionListUrl, data);
    }

    handleDialog = (item, index) => {
        this.setState({ modalShow: true, selectedComplaint: item?.["COMPLAINTNO"], INITIATOR: item?.["INITIATOR"], selectedIndex: index });
    }

    async submitAction(url, param) {
        try {
            var options = await post(url, param);
            if (options["Massage"]) { this.setState({ btnLoading: false, selectedIndex: '' }) }
            Swal.fire("", options["Massage"], options["MsgType"]).then((result) => {
            });
        } catch (error) {
            this.setState({ btnLoading: false, selectedIndex: '' })
        }
    }

    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>Action List </h3>
                </div>
                <div className=''>
                    <div className='col-md-12  table-responsive"'>
                        {this.state.loading ? (
                            <table className='table table-bordered' id="example" ref={this.tableRef} style={{ width: "100%" }}>
                                <thead>
                                    <tr>
                                        {/* Define your table headers here */}
                                        <th>Complaint No.</th>
                                        <th>Date of Logging</th>
                                        {/* <th>Capture User pno.</th> */}
                                        <th>Location</th>
                                        <th >Plant</th>
                                        <th>Material</th>
                                        <th>Nature</th>
                                        <th>Impact</th>
                                        <th>Description</th>
                                        {/* <th>Actions</th> */}
                                        <th>Remarks</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state?.actionList?.map((item, index) => {
                                        let isBtnDisabled = this.checkBtnDisabled(item)
                                        let remarksValue = item["TCWI_REMARKS"]?.replace(/<[^>]+>/g, '');
                                        let descValue = item["DESCRIPTION"]?.replace(/<[^>]+>/g, '');
                                        return <tr key={index}>
                                            {/* Render your data here */}
                                            <td>{item["COMPLAINTNO"]}</td>
                                            <td>{item["DATEOFLOGGING"]}</td>
                                            {/* <td>{item["USERCONTACTNO"]}</td> */}
                                            <td>{item["LOCATION"]}</td>
                                            <td>{item["PLANT"]}</td>
                                            <td>{item["MATERIAL"]}</td>
                                            <td>{item["NATURE"]}</td>
                                            <td>{item["IMPACT"]}</td>
                                            <td>
                                                <input type="text" onChange={this.handleDescChange.bind(this, index)} maxLength="200" className='form-control Txt' defaultValue={descValue}  ></input>
                                            </td>
                                            <td>
                                                <input type="text" onChange={this.handleRemarkChange.bind(this, index)} maxLength="200" className='form-control Txt' defaultValue={remarksValue} ></input>
                                            </td>
                                            <td><Button className={isBtnDisabled ? 'btn btn-success  btn-sm disabled not-allowed' : 'btn btn-success btn-sm'} disabled={isBtnDisabled} onClick={() => this.handleDialog(item, index)}>{item?.CAPAID ? 'Update CAPA' : 'Add CAPA'}</Button></td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        ) : (
                            <PageLoader error={this.state.error} refreshPage={() => this.BindActionList(GetActionsUrl, { "USERNAME": this.state.USERNAME })} />
                        )}
                        {this.state.modalShow &&
                            <ComplaintModal modalShow={this.state.modalShow} closeDialog={() => this.setState({ modalShow: false, selectedComplaint: "", INITIATOR: '' })}
                                submitCAPA={(flag) => this.handleSubmit(flag)}
                                complainId={this.state.selectedComplaint} INITIATOR={this.state.INITIATOR} />
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default Action_List;
