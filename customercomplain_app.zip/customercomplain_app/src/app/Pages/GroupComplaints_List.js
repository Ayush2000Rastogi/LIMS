import React, { Component } from 'react';
import { get, post } from '../ApiMethod';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import Swal from 'sweetalert2';
import 'datatables.net';
import $ from 'jquery';
import { GetGroupUrl, InsertGroupUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import secureLocalStorage from 'react-secure-storage';
import PageLoader from '../basic-ui/PageLoader';
import JSZip from 'jszip';
import 'datatables.net-buttons/js/dataTables.buttons.min';
import 'datatables.net-buttons/js/buttons.html5.min';
window.JSZip = JSZip;

class GroupComplaints_List extends Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            USERNAME: UserName,
            dataList: [],
            selectedComplaint: "",
            MasterChecked: false,
            SelectedList: [],
            isBtnLoading: false,
            error: false
        };
    }
    componentDidMount() {
        this.BindList(GetGroupUrl);
    }

    componentWillUnmount() {
        const dataTable = $(this.tableRef.current).DataTable();
        dataTable.destroy();
    }

    async BindData(url) {
        try {
            var options = await get(url);
            this.setState({ dataList: options.d });
            this.setState({ loading: true });
        } catch (error) {
        }
    }

    async BindList(url, param) {
        try {
            var options = await get(url);
            this.setState({ dataList: options.d });
            this.setState({ loading: true });
            let table = $(this.tableRef.current).DataTable(
                {
                    dom: "<'row'<'col-sm-12 col-md-6'B><'col-sm-12 col-md-6'f>>" +
                        "<'row'<'col-sm-12'tr>>" +
                        "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
                    buttons: [{
                        extend: 'excel',
                        text: 'Export',
                        filename: `data_${new Date().toISOString().split('T')[0]}`,
                        className: 'btn btn-success btn-sm',
                    }],
                    drawCallback: function () {
                        var hasRows = this.api().rows({ filter: 'applied' }).data().length > 0;
                        $('.buttons-excel')[0].style.visibility = hasRows ? 'visible' : 'hidden'
                    },
                    orderCellsTop: true,
                    initComplete: function () {
                        var table = this.api();
                        table.columns([2]).every(function (colIdx) {
                            var column = this;
                            var input = $('<input id="input"  type="text" style="padding:4px; border:1px solid" placeholder="Search by Date" />')
                                .appendTo($("thead tr:eq(1) td").eq(this.index()))
                                .off('keyup change')
                                .on('change', function (e) {
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})';
                                    column
                                        .column(colIdx)
                                        .search(
                                            this.value !== ''
                                                ? regexr.replace('{search}', '(((' + this.value + ')))')
                                                : '',
                                            this.value !== '',
                                            this.value === ''
                                        )
                                        .draw();
                                })
                                .on('keyup', function (e) {
                                    e.stopPropagation();
                                    $(this).trigger('change');
                                });
                        });
                        table.columns([3, 4, 5]).every(function () {
                            var column = this;
                            var select = $('<select style="padding:4px"><option value="">Please Select</option></select>')
                                .appendTo($("thead tr:eq(1) td").eq(this.index()))
                                .on('change', function () {
                                    var val = $.fn.dataTable.util.escapeRegex(
                                        $(this).val()
                                    );
                                    column
                                        .search(val ? '^' + val + '$' : '', true, false)
                                        .draw();
                                });

                            column.data().unique().sort().each(function (d, j) {
                                select.append('<option value="' + d + '">' + d + '</option>')
                            });
                        });
                    },
                    'destroy': true,
                    'rowsGroup': [0, 1],
                    'responsive': true,
                    "paging": true,
                    "bLengthChange": false,
                    "pageLength": 7,
                    "ordering": false,
                    "info": false,
                    "searching": true,
                    "scrollX": true,
                }
            ).columns.adjust();
        } catch (error) {
            this.setState({ error: true })
        }
    }

    handleSubmit = () => {
        this.getSelectedRows()
        let newPayload = this.state.SelectedList.map((item) => {
            return {
                "GROUPID": "",
                "ID": item?.ID,
                "DT": item?.DT,
                "LOCATION": "",
                "PLANT": item?.PLANTID,
                "GRADE": item?.GRADE,
                "MATERIALID": item?.MATERIALID,
                "NATUREID": item?.NATUREID,
                "IMPACT": item?.IMPACT,
                "REMARKS": item?.REMARKS,
                "USERNAME": this.state.USERNAME,
                "INITIATOR": item?.INITIATOR
            }
        })
        this.insertGroup(InsertGroupUrl, newPayload);
    }

    async insertGroup(url, param) {
        try {
            this.setState({
                isBtnLoading: true,
            });
            var options = await post(url, param);
            if (options["Massage"]) {
                this.setState({
                    isBtnLoading: false,
                });
            }
            var text = options["Massage"] + `<br>ID : ${options["ID"]}`;
            Swal.fire("", text, options["MsgType"]).then((result) => {
                this.BindData(GetGroupUrl);
            });
        } catch (error) {
            this.setState({
                isBtnLoading: false,
            });
            Swal.fire("", "Error", 'error');
        }
    }

    onMasterCheck(e) {
        let tempList = this.state.dataList;
        tempList.map((user) => (user.selected = e.target.checked));
        this.setState({
            MasterChecked: e.target.checked,
            dataList: tempList,
            SelectedList: this.state.dataList.filter((e) => e.selected),
        });
    }

    onItemCheck(e, item) {
        let tempList = this.state.dataList;
        tempList.map((user) => {
            if (user?.ID === item?.ID) {
                user.selected = e.target.checked;
            }
            return user;
        });

        const totalItems = this.state.dataList.length;
        const totalCheckedItems = tempList.filter((e) => e.selected).length;

        this.setState({
            MasterChecked: totalItems === totalCheckedItems,
            dataList: tempList,
            SelectedList: this.state.dataList.filter((e) => e.selected),
        });
    }

    getSelectedRows() {
        this.setState({
            SelectedList: this.state.dataList.filter((e) => e.selected),
        });
    }

    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>Complaints grouping </h3>
                </div>
                <div className="col-md-12 text-right mb-2">
                    <Button className={'btn  btn-sm'} disabled={this.state.SelectedList?.length === 0 ? true : false} onClick={this.handleSubmit.bind(this)}>Group Complaints
                        {this.state.isBtnLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
                    </Button>
                </div>
                <div className=''>
                    <div className='col-md-12  table-responsive"'>
                        {this.state.loading ? (
                            <table className='table table-bordered' ref={this.tableRef} style={{ width: "100%" }}>
                                <thead>
                                    <tr>
                                        <th>
                                            <div className="form-check ml-2">
                                                <label className="form-check-label">
                                                    <input type="checkbox"
                                                        checked={this.state.MasterChecked}
                                                        id="mastercheck"
                                                        onChange={(e) => this.onMasterCheck(e)}
                                                        className="form-check-input" />
                                                    <i className="input-helper"></i>
                                                </label>
                                            </div>
                                        </th>
                                        <th>Complaint No.</th>
                                        <th>Date of Logging</th>
                                        <th >Plant</th>
                                        <th>Material</th>
                                        <th>GRADE</th>
                                        <th>Nature</th>
                                        <th>Impact</th>
                                        <th>Remarks</th>
                                        <th>Created By</th>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </thead>

                                <tbody>
                                    {this.state?.dataList?.map((item, index) => {
                                        let isVisible = item?.ISGROUPED === "0" ? true : false
                                        let remarksValue = item["REMARKS"]?.replace(/<[^>]+>/g, '');
                                        return isVisible && <tr key={index}>
                                            <td>
                                                <div className="form-check ml-2">
                                                    <label className="form-check-label">
                                                        <input type="checkbox"
                                                            checked={item.selected || false}
                                                            id="rowcheck"
                                                            onChange={(e) => this.onItemCheck(e, item)}
                                                            className="form-check-input" />
                                                        <i className="input-helper"></i>
                                                    </label>
                                                </div>
                                            </td>
                                            <td>{item["ID"]}</td>
                                            <td>{item["DT"]}</td>
                                            <td>{item["PLANT"]}</td>
                                            <td>{item["MATERIAL"]}</td>
                                            <td>{item["GRADE"]}</td>
                                            <td>{item["NATURE"]}</td>
                                            <td>{item["IMPACT"]}</td>
                                            <td>{remarksValue}</td>
                                            <td>{item["COMPLAINTASSIGN"]}</td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        ) : (
                            <PageLoader error={this.state.error} refreshPage={() => this.BindList(GetGroupUrl)} />
                        )}
                    </div>
                </div>
            </div>
        )
    }
}

export default GroupComplaints_List;
