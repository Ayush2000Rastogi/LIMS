import React, { Component } from 'react';
import { post } from '../ApiMethod';
import Select from 'react-select';
import '../Pages/User_Complaint.css';
import 'datatables.net-dt/css/jquery.dataTables.css';
import Swal from 'sweetalert2';
import 'datatables.net';
import $ from 'jquery';
import { GetCapaUrl } from '../Constant';
import { Button } from 'react-bootstrap';
import ComplaintModal from '../form-elements/ComplaintModal';
import secureLocalStorage from 'react-secure-storage';
import PageLoader from '../basic-ui/PageLoader';


class Capa_List extends Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
        let UserName = secureLocalStorage.getItem("USERID")
        this.state = {
            loading: false,
            actions: [
                { value: "ACCEPT", label: "Accept" },
                { value: "RETURN", label: "Return" },
            ],
            USERNAME: UserName,
            actionList: [],
            modalShow: false,
            selectedComplaint: "",
            INITIATOR: "",
            error: false
        };
    }
    componentDidMount() {
        this.BindActionList(GetCapaUrl, { "USERNAME": this.state.USERNAME });
    }

    componentWillUnmount() {
        // Destroy the DataTable when the component unmounts to prevent memory leaks
        const dataTable = $(this.tableRef.current).DataTable();
        dataTable.destroy();
    }

    async BindActionList(url, param) {
        try {
            var options = await post(url, param);
            // debugger;

            this.setState({ actionList: options.d });
            this.setState({ loading: true });
            $(this.tableRef.current).DataTable(
                {
                    destroy: true,
                    'rowsGroup': [0, 1],
                    responsive: true,
                    "paging": true,
                    "bLengthChange": false,
                    "pageLength": 7,
                    "ordering": false,
                    "info": false,
                    "searching": true,
                    "scrollX": true,
                    "fixedColumns": {
                        leftColumns: 2
                    }
                }
            );
            // Handle the data
        } catch (error) {
            this.setState({ error: true })
            // Handle errors
        }
    }

    handleDialog = (item, index) => {
        this.setState({ modalShow: true, selectedComplaint: item?.["COMPLAINTNO"], INITIATOR: item?.["INITIATOR"] });
    }


    render() {
        return (
            <div>
                <div className="proBanner">
                </div>
                <div className="page-header">
                    <h3 className="page-title">
                        <span className="page-title-icon bg-gradient-primary text-white mr-2">
                            <i className="mdi mdi-account-convert"></i>
                        </span>Capa List </h3>
                </div>
                <div className=''>
                    <div className='col-md-12  table-responsive"'>
                        {this.state.loading ? (
                            <table className='table table-bordered' ref={this.tableRef} style={{ width: "100%" }}>
                                <thead>
                                    <tr>
                                        {/* Define your table headers here */}
                                        <th>Complaint No.</th>
                                        <th>Date of Logging</th>
                                        {/* <th>Capture User pno.</th> */}
                                        <th>Location</th>
                                        <th >Plant</th>
                                        <th>Material</th>
                                        <th>Nature</th>
                                        <th>Impact</th>
                                        <th>Description</th>
                                        <th>Remarks</th>
                                        <th>Created By</th>
                                        <th></th>

                                        {/* Add more columns as needed */}
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state?.actionList?.map((item, index) => {
                                        let remarksValue = item["TCWI_REMARKS"]?.replace(/<[^>]+>/g, '');
                                        let descValue = item["DESCRIPTION"]?.replace(/<[^>]+>/g, '');
                                        return <tr key={index}>
                                            {/* Render your data here */}
                                            <td>{item["COMPLAINTNO"]}</td>
                                            <td>{item["DATEOFLOGGING"]}</td>
                                            {/* <td>{item["USERCONTACTNO"]}</td> */}
                                            <td>{item["LOCATION"]}</td>
                                            <td>{item["PLANT"]}</td>
                                            <td>{item["MATERIAL"]}</td>
                                            <td>{item["NATURE"]}</td>
                                            <td>{item["IMPACT"]}</td>
                                            <td>{descValue}</td>
                                            <td>{remarksValue}</td>
                                            <td>{item["CREATEDBY"]}</td>
                                            <td><Button className={'w-100 btn btn-success btn-sm'} onClick={() => this.handleDialog(item, index)}>{item?.CAPAID ? 'Update CAPA' : 'Add CAPA'}</Button></td>
                                        </tr>
                                    })}
                                </tbody>
                            </table>
                        ) : (
                            <PageLoader error={this.state.error} refreshPage={() => this.BindActionList(GetCapaUrl, { "USERNAME": this.state.USERNAME })} />
                        )}
                        {this.state.modalShow &&
                            <ComplaintModal modalShow={this.state.modalShow} closeDialog={() => this.setState({ modalShow: false, selectedComplaint: "", INITIATOR: '' })} complainId={this.state.selectedComplaint} INITIATOR={this.state.INITIATOR} />
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default Capa_List;
