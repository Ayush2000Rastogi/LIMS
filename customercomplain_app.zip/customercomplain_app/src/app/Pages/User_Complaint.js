import React, { Component } from 'react';
import { postFile, post } from '../ApiMethod';
import { gradeUrl, impactUrl, locationUrl, materialUrl, natureUrl, sublocationUrl, InsertComplainturl, UploadFileurl, subNatureUrl } from '../Constant';
import MyStatefulEditor from '../../FormControl/Richtextbox';
import Swal from 'sweetalert2';
import '../Pages/User_Complaint.css';
import Select, { components } from "react-select";
import { useState } from 'react';
import secureLocalStorage from 'react-secure-storage';


class User_Complaint extends Component {
  constructor(props) {
    super(props);
    let UserName = secureLocalStorage.getItem("USERID")
    this.state = {
      LOCID: '',
      SELELOCID: [],
      locationList: [],
      subLocationList: [],
      natureList: [],
      subNatureList: [],
      PLANTID: '',
      SELEPLANTID: [],
      MATID: '',
      materialList: [],
      SELEMATTID: [],
      SELENATUREID: [],
      NATUREID: '',
      SUBNATUREID: '',
      SELESUBNATUREID: [],
      gradeList: [],
      GRADEID: '',
      SELEGRADEID: [],
      impactList: [],
      IMPACTID: [],
      SELEIMPACTID: [],
      COMMENT: '',
      COMPLAINTID: '',
      USERNAME: UserName,
      setSelectedFile: null,
      isSubNatureDDLVisible: false,
      isLoading: false
    };
  }

  componentDidMount() {
    this.BindLocationDDL(locationUrl, {});
    this.BindMaterialDDL(materialUrl, {});
  }

  async BindLocationDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({ locationList: opt });
    } catch (error) {
    }
  }

  async BindMaterialDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({ materialList: opt });
    } catch (error) {
    }
  }

  async BindSubDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({ subLocationList: opt, SELEPLANTID: [], PLANTID: null });
    } catch (error) {
    }
  }

  async BindNatureDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({
        natureList: opt,
        SELENATUREID: [],
        NATUREID: '',
        SUBNATUREID: null,
        isSubNatureDDLVisible: false
      });
    } catch (error) {
    }
  }

  async BindSubNatureDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["NAME"] },
        )
      }
      this.setState({ subNatureList: opt });
    } catch (error) {
    }
  }

  async BindGradeDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({
        gradeList: opt,
        SELEGRADEID: [],
        GRADEID: ''
      });
    } catch (error) {
    }
  }

  async BindImpactDDL(url, param) {
    try {
      var options = await post(url, param);
      var opt = [];
      for (var i = 0; i < options.d.length; i++) {
        opt.push(
          { value: options.d[i]["ID"], label: options.d[i]["VAL"] },
        )
      }
      this.setState({ impactList: opt, SELEIMPACTID: [], IMPACTID: [] });
    } catch (error) {
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
  };

  handleLocationChange = (locObj) => {
    if (locObj?.value) {
      this.setState({
        LOCID: locObj?.value,
        SELELOCID: locObj
      });
      this.BindSubDDL(sublocationUrl, { LOCID: locObj?.value });
    }
    else {
      this.setState({
        LOCID: '',
        SELELOCID: [],
        PLANTID: '',
        SELEPLANTID: []
      });
    }
  };

  handleNatureChange = (natureObj) => {
    if (natureObj?.value) {
      this.setState({
        NATUREID: natureObj?.value,
        SELENATUREID: natureObj
      });
      if (natureObj?.value === 'NA_43') {
        this.BindSubNatureDDL(subNatureUrl, {
          NATUREID: natureObj?.value,
          MATERIALID: this.state.MATID
        });
        this.setState({
          isSubNatureDDLVisible: true,
        });
      }
      else {
        this.setState({
          SUBNATUREID: null,
          subNatureList: [],
          isSubNatureDDLVisible: false
        });
      }
    }
    else {
      this.setState({
        NATUREID: null,
        SELENATUREID: [],
        SUBNATUREID: null,
        isSubNatureDDLVisible: false
      });
    }
  };

  handleSubNatureChange = (subNatureObj) => {
    if (subNatureObj?.value) {
      this.setState({
        SUBNATUREID: subNatureObj?.value,
        SELESUBNATUREID: subNatureObj
      });
    }
    else {
      this.setState({
        SUBNATUREID: '',
        SELESUBNATUREID: null
      });
    }
  };

  handleGradeChange = (gradeObj) => {
    if (gradeObj?.value) {
      this.setState({
        GRADEID: gradeObj?.value,
        SELEGRADEID: gradeObj
      });
    }
    else {
      this.setState({
        GRADEID: '',
        SELEGRADEID: []
      });
    }
  };

  handleImpactChange = (event) => {
    var obj = [];
    this.setState({
      SELEIMPACTID: event || [],
    });
    for (var i = 0; i < event?.length; i++) {
      obj.push({
        IMPACTID: event[i]["value"],
        USERNAME: this.state.USERNAME
      })
    }
    this.setState({
      IMPACTID: obj,
    });
  };

  handleMaterialChange = (matObj) => {
    if (matObj?.value) {
      this.setState({
        MATID: matObj?.value,
        SELEMATTID: matObj
      });
      this.BindNatureDDL(natureUrl, { MATID: matObj?.value });
      this.BindGradeDDL(gradeUrl, { MATID: matObj?.value });
      this.BindImpactDDL(impactUrl, { MATID: matObj?.value });
    } else {
      this.setState({
        MATID: null,
        SELEMATTID: [],
        SELEIMPACTID: [],
        IMPACTID: [],
        GRADEID: null,
        SELEGRADEID: [],
        NATUREID: null,
        SELENATUREID: [],
        SELESUBNATUREID: [],
        SUBNATUREID: null,
        isSubNatureDDLVisible: false,
        natureList: [],
        gradeList: [],
        impactList: [],
        subNatureList: []
      });
    }
  };

  handleSubLocationChange = (plantObj) => {
    this.setState({
      PLANTID: plantObj?.value,
      SELEPLANTID: plantObj
    });
  };

  checkBtnDisabled = () => {
    const objData = this.state;
    if (objData?.LOCID && objData?.PLANTID && objData?.MATID && objData?.GRADEID && objData?.NATUREID && objData?.USERNAME && objData?.SELEIMPACTID?.length > 0) {
      if (objData?.isSubNatureDDLVisible) {
        if (objData?.SUBNATUREID)
          return false
        else
          return true
      }
      else return false
    }
    else
      return true
  }

  onRegister = () => {
    this.setState({
      isLoading: true,
    });
    var data = {
      complaint: {
        COMPLAINTID: this.state.COMPLAINTID,
        LOCID: this.state.LOCID,
        LOCNAME: this.state.SELELOCID?.label,
        PLANTID: this.state.PLANTID,
        MATID: this.state.MATID,
        GRADEID: this.state.GRADEID,
        NATUREID: this.state.NATUREID,
        SUBNATUREID: this.state.SUBNATUREID,
        COMMENT: this.state.COMMENT,
        USERNAME: this.state.USERNAME
      },
      IMPACTID: this.state.IMPACTID,
    }
    this.insertComplaint(InsertComplainturl, data);
  }

  handleFileChange = (event) => {
    this.setState({ setSelectedFile: event.target.files[0] });
  };

  handleUpload = () => {
    this.UploadFileData();
  };

  async UploadFileData(id) {
    if (this.state.setSelectedFile != null) {
      const formData = new FormData();
      formData.append('file', this.state.setSelectedFile);
      formData.append('id', id);
      formData.append('UserName', this.state.USERNAME);
      var options = await postFile(UploadFileurl, formData);
      Swal.fire("", "File Uploaded Successfully", "info");
    }
  }

  async insertComplaint(url, param) {
    try {
      var options = await post(url, param);
      if (options["ID"]?.length > 0) {
        await this.UploadFileData(options["ID"]);
      }
      if (options["Massage"]) {
        this.setState({
          isLoading: false,
        });
      }
      var text = options["Massage"] + `<br>ID : ${options["ID"]}`;
      Swal.fire("", text, options["MsgType"]).then((result) => {
      });
    } catch (error) {
      this.setState({
        isLoading: false,
      });
      Swal.fire("", "Error", 'error');
    }
  }

  onRichChange = (value) => {
    try {

      this.setState({
        COMMENT: value
      });
    }
    catch (e) { }
  };

  render() {
    let isBtnDisabled = this.checkBtnDisabled()
    return (
      <>
        <div>
          <div className="proBanner">
          </div>
          <div className="page-header">
            <h3 className="page-title">
              <span className="page-title-icon bg-gradient-primary text-white mr-2">
                <i className="mdi mdi-account-convert"></i>
              </span> Register Ticket  </h3>
          </div>
          <div className="row">
            <div className="col-md-3">
              <div className='form-group'>
                <label><span className='required'>*</span>Select Location:</label>
                <Select
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELELOCID}
                  onChange={this.handleLocationChange}
                  options={this.state.locationList}
                  closeMenuOnSelect={true}
                  hideSelectedOptions={false}
                  isClearable={true}
                />
              </div></div>
            <div className="col-md-3">
              <div className='form-group'>
                <label><span className='required'>*</span>Select Plant:</label>
                <Select
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELEPLANTID}
                  onChange={this.handleSubLocationChange}
                  options={this.state.subLocationList}
                  closeMenuOnSelect={true}
                  hideSelectedOptions={false}
                  isClearable={true}
                />
              </div></div>
            <div className="col-md-3">
              <div className='form-group'>
                <label><span className='required'>*</span>Select Material:</label>
                <Select
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELEMATTID}
                  onChange={this.handleMaterialChange}
                  options={this.state.materialList}
                  closeMenuOnSelect={true}
                  hideSelectedOptions={false}
                  isClearable={true}
                />
              </div></div>

            <div className="col-md-3">
              <div className='form-group'>
                <label><span className='required'>*</span>Nature</label>
                <Select
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELENATUREID}
                  onChange={this.handleNatureChange}
                  options={this.state.natureList}
                  closeMenuOnSelect={true}
                  hideSelectedOptions={false}
                  isClearable={true}
                />
              </div></div>
            {this.state.isSubNatureDDLVisible &&
              <div className="col-md-3">
                <div className='form-group'>
                  <label><span className='required'>*</span>Sub Nature</label>
                  <Select
                    menuPortalTarget={document.body}
                    styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                    value={this.state.SELESUBNATUREID}
                    onChange={this.handleSubNatureChange}
                    options={this.state.subNatureList}
                    closeMenuOnSelect={true}
                    hideSelectedOptions={false}
                    isClearable={true}
                  />
                </div></div>
            }
            <div className="col-md-3">
              <div className='form-group'>
                <label><span className='required'>*</span>Grade</label>
                <Select
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELEGRADEID}
                  onChange={this.handleGradeChange}
                  options={this.state.gradeList}
                  closeMenuOnSelect={true}
                  hideSelectedOptions={false}
                  isClearable={true}
                />
              </div></div>
            <div className="col-md-6">
              <div className='form-group'>
                <label><span className='required'>*</span>Impact</label>
                <Select
                  isMulti
                  menuPortalTarget={document.body}
                  styles={{ menuPortal: base => ({ ...base, zIndex: 9999 }) }}
                  value={this.state.SELEIMPACTID}
                  onChange={this.handleImpactChange}
                  options={this.state.impactList}
                  closeMenuOnSelect={false}
                  hideSelectedOptions={false}
                  components={{
                    Option: InputOption
                  }}
                />
              </div></div>
            <div className='col-md-6'>
              <input type="file" className='form-control' onChange={this.handleFileChange} />
            </div>
            <div className="col-md-6">
              <label style={{ color: "transparent" }}>Select Location:</label>
              <button style={{ float: "right" }} onClick={this.onRegister} className='btn btn-social-icon-text btn-facebook' type="submit" disabled={isBtnDisabled}>
                <i className="mdi mdi-file-check btn-icon-prepend"></i>Register
                {this.state.isLoading && <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true" style={{ marginLeft: "7px" }}></span>}
              </button>
            </div></div>
          <hr></hr>
          <div className='row'>
            <div className='col-md-12'>
              <div className='form-group'>
                <label><span className='required'>*</span>Please Enter Complaint Description</label>
                <MyStatefulEditor onRichChange={this.onRichChange}></MyStatefulEditor>
              </div></div>
          </div>
        </div >
      </>
    );
  }
}

export const InputOption = ({
  getStyles,
  Icon,
  isDisabled,
  isFocused,
  isSelected,
  children,
  innerProps,
  ...rest
}) => {
  const [isActive, setIsActive] = useState(false);
  const onMouseDown = () => setIsActive(true);
  const onMouseUp = () => setIsActive(false);
  const onMouseLeave = () => setIsActive(false);

  let bg = "transparent";
  if (isFocused) bg = "#eee";
  if (isActive) bg = "#B2D4FF";

  const style = {
    alignItems: "center",
    backgroundColor: bg,
    color: "inherit",
    display: "flex "
  };

  const props = {
    ...innerProps,
    onMouseDown,
    onMouseUp,
    onMouseLeave,
    style
  };

  return (
    <components.Option
      {...rest}
      isDisabled={isDisabled}
      isFocused={isFocused}
      isSelected={isSelected}
      getStyles={getStyles}
      innerProps={props}
    >
      <input type="checkbox" readOnly checked={isSelected} style={{ marginRight: "5px" }} />
      {children}
    </components.Option>
  );
};


export default User_Complaint;
