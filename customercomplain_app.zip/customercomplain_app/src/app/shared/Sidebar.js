import React, { Component } from 'react';
import { Link, withRouter } from 'react-router-dom';
import secureLocalStorage from 'react-secure-storage';


class Sidebar extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  toggleMenuState(menuState) {
    if (this.state[menuState]) {
      this.setState({ [menuState]: false });
    } else if (Object.keys(this.state).length === 0) {
      this.setState({ [menuState]: true });
    } else {
      Object.keys(this.state).forEach(i => {
        this.setState({ [i]: false });
      });
      this.setState({ [menuState]: true });
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.location !== prevProps.location) {
      this.onRouteChanged();
    }
  }

  onRouteChanged() {
    document.querySelector('#sidebar').classList.remove('active');
    Object.keys(this.state).forEach(i => {
      this.setState({ [i]: false });
    });

    // const dropdownPaths = [
    //   { path: '/apps', state: 'appsMenuOpen' },
    //   { path: '/basic-ui', state: 'basicUiMenuOpen' },
    //   { path: '/advanced-ui', state: 'advancedUiMenuOpen' },
    //   { path: '/form-elements', state: 'formElementsMenuOpen' },
    //   { path: '/tables', state: 'tablesMenuOpen' },
    //   { path: '/maps', state: 'mapsMenuOpen' },
    //   { path: '/icons', state: 'iconsMenuOpen' },
    //   { path: '/charts', state: 'chartsMenuOpen' },
    //   { path: '/user-pages', state: 'userPagesMenuOpen' },
    //   { path: '/error-pages', state: 'errorPagesMenuOpen' },
    //   { path: '/general-pages', state: 'generalPagesMenuOpen' },
    //   { path: '/ecommerce', state: 'ecommercePagesMenuOpen' },
    // ];

    // dropdownPaths.forEach((obj => {
    //   if (this.isPathActive(obj.path)) {
    //     this.setState({ [obj.state]: true })
    //   }
    // }));

  }

  render() {
    let MENU = secureLocalStorage.getItem("MENU");
    return (
      <nav className="sidebar sidebar-offcanvas" id="sidebar">
        <ul className="nav">
          {MENU?.length > 0 && MENU?.map((item) =>
            <li key={item?.path} className={this.isPathActive(item?.path) ? 'nav-item active' : 'nav-item'}>
              <Link className="nav-link" to={item?.path}>
                <span className="menu-title">{item?.name}</span>
                <i className={`mdi ${item?.icon} menu-icon`}></i>
              </Link>
            </li>
          )}
        </ul>
      </nav >
    );
  }

  isPathActive(path) {
    return this.props.location.pathname.startsWith(path);
  }

  componentDidMount() {
    this.onRouteChanged();
    // add class 'hover-open' to sidebar navitem while hover in sidebar-icon-only menu
    const body = document.querySelector('body');
    document.querySelectorAll('.sidebar .nav-item').forEach((el) => {

      el.addEventListener('mouseover', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.add('hover-open');
        }
      });
      el.addEventListener('mouseout', function () {
        if (body.classList.contains('sidebar-icon-only')) {
          el.classList.remove('hover-open');
        }
      });
    });
  }

}

export default withRouter(Sidebar);