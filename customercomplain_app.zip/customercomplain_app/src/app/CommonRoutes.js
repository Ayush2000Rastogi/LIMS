import { lazy } from 'react';

const User_Complaint = lazy(() => import('./Pages/User_Complaint'));
const Complaint_List = lazy(() => import('./Pages/Complaint_List'));
const Action_List = lazy(() => import('./Pages/Action_List'));
const GroupComplaints_List = lazy(() => import('./Pages/GroupComplaints_List'));
const GroupReport_List = lazy(() => import('./Pages/GroupReport_List'));
const Ticket_Analysis = lazy(() => import('./Pages/Ticket_Analysis'));
const Ticket_Reassign = lazy(() => import('./Pages/TicketReassign_List'));
const MasterScreen = lazy(() => import('./Pages/MasterScreen'));
const MyComplaint_List = lazy(() => import('./Pages/MyComplaint_List'));

export const CommonRoutes = [
    {
        id: "Register_Ticket",
        value: User_Complaint,
        path: "/dashboard",
        name: "Register Ticket",
        icon: "mdi-home"
    },
    {
        id: "Ticket_Assignment",
        value: Complaint_List,
        path: "/list",
        name: "Ticket Assignment",
        icon: "mdi-gamepad"
    },
    {
        id: "Action_List",
        value: Action_List,
        path: "/actions",
        name: "Action List",
        icon: "mdi-gamepad"
    },
    {
        id: "Group_Complaints",
        value: GroupComplaints_List,
        path: "/group",
        name: "Group Complaints",
        icon: "mdi-gamepad"
    },
    {
        id: "Group_Complaints_Report",
        value: GroupReport_List,
        path: "/report",
        name: "Group Complaints Report",
        icon: "mdi-gamepad"
    },
    {
        id: "Ticket_Reassignment",
        value: Ticket_Reassign,
        path: "/reassign",
        name: "Ticket Reassignment",
        icon: "mdi-gamepad"
    },
    {
        id: "Ticket_Analysis",
        value: Ticket_Analysis,
        path: "/analysis",
        name: "Ticket Analysis",
        icon: "mdi-gamepad"
    },
    {
        id: "Master",
        value: MasterScreen,
        path: "/master",
        name: "Master",
        icon: "mdi-gamepad"
    },
    {
        id: "My_complaint_List",
        value: MyComplaint_List,
        path: "/mycomplaints",
        name: "My Complaint List",
        icon: "mdi-gamepad"
    },
]