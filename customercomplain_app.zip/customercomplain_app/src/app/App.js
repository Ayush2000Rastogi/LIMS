 
   import React, { Component } from 'react';
   import { withRouter } from 'react-router-dom';
   import './App.scss';
   import AppRoutes from './AppRoutes';
   import Navbar from './shared/Navbar';
   import Sidebar from './shared/Sidebar';
   import CryptoJS from "crypto-js";
   import Footer from './shared/Footer';
   import { withTranslation } from 'react-i18next';
   import secureLocalStorage from 'react-secure-storage';
   import { AUTH_URL, post } from './ApiMethod';
   import { GetMenuList } from './Constant';
   import { CommonRoutes } from './CommonRoutes';
   import { Modal } from 'react-bootstrap';
   
   
   class App extends Component {
     state = {
       menuList: [],
       modalShow: false,
       loading: false
     }
     componentDidMount() {
       this.getUserData()
       this.onRouteChanged();
     }
   
     getUserData = () => {
       this.setState({ loading: true })
       fetch(AUTH_URL, {
         method: 'Get',
         credentials: 'include',
         mode: 'cors',
       })
         .then((response) => {
           return response.json();
         })
         .then(data => {
           this.decryptData(JSON.parse(data).auth);
         })
         .catch((error) => this.setState({ modalShow: true, loading: false }));
     }
   
     decryptData = (txt) => {
       var ciphertext = txt;
       var key = "8056483646328763";
       var iv = "8056483646328763";
   
       var ciphertextWA = CryptoJS.enc.Base64.parse(ciphertext);
       var keyWA = CryptoJS.enc.Utf8.parse(key);
       var ivWA = CryptoJS.enc.Utf8.parse(iv);
       var ciphertextCP = { ciphertext: ciphertextWA };
   
       var decrypted = CryptoJS.AES.decrypt(
         ciphertextCP,
         keyWA,
         { iv: ivWA }
       );
       var adid = decrypted.toString(CryptoJS.enc.Utf8);
       if (adid !== "") {
         if (adid.split('\\')[0] === "TATASTEEL" && adid.split('\\').length > 1) {
           let userName = adid.split('\\')[1]
           if (userName) {
             secureLocalStorage.setItem('USERID', userName);
             let payload = {
               "USERNAME": userName
             }
             this.getMenuData(GetMenuList, payload)
             this.setState({ modalShow: false })
           }
           else {
             this.setState({ loading: false })
             this.setState({ modalShow: true })
           }
         }
       }
     }
   
     async getMenuData(url, param) {
       try {
         var data = await post(url, param);
         if (data) {
           const result = CommonRoutes?.filter(item => data?.d?.map(data => data?.MENUID).includes(item?.id))
           secureLocalStorage.setItem('MENU', result);
           this.setState({ menuList: result })
           this.setState({ loading: false })
         }
       } catch (error) {
         this.setState({ menuList: [] })
         this.setState({ loading: false })
       }
     }
   
     render() {
       let navbarComponent = !this.state.isFullPageLayout ? <Navbar /> : '';
       let sidebarComponent = !this.state.isFullPageLayout ? <Sidebar /> : '';
       let footerComponent = !this.state.isFullPageLayout ? <Footer /> : '';
       return (
         <>
           {this.state.loading ?
             <div class="vh-100 d-flex justify-content-center align-items-center">
               <div class="spinner-border" role="status">
                 <span class="sr-only">Loading...</span>
               </div>
             </div>
             : <>
               {this.state.modalShow ?
                 < div className="container-scroller">
                   <div className="container-fluid page-body-wrapper">
                     <Modal show={this.state.modalShow}
                       centered
                       className="my-modal"
                       backdrop="static"
                       keyboard={false}>
                       <Modal.Header >
                         <Modal.Title><span style={{ color: "red" }}>Error!</span></Modal.Title>
                       </Modal.Header>
                       <Modal.Body>
                         <h4>Authentication Error</h4>
                       </Modal.Body>
                     </Modal >
                   </div>
                 </div> :
                 <div className="container-scroller">
                   {navbarComponent}
                   <div className="container-fluid page-body-wrapper">
                     {sidebarComponent}
                     <div className="main-panel">
                       <div className="content-wrapper">
                         {this.state.menuList?.length > 0 &&
                           <AppRoutes />
                         }
                       </div>
                       {footerComponent}
                     </div>
                   </div>
                 </div>
               }
             </>
           }
         </>
       );
     }
   
     componentDidUpdate(prevProps) {
       if (this.props.location !== prevProps.location) {
         this.onRouteChanged();
       }
     }
   
     onRouteChanged() {
       const { i18n } = this.props;
       const body = document.querySelector('body');
       if (this.props.location.pathname === '/layout/RtlLayout') {
         body.classList.add('rtl');
         i18n.changeLanguage('ar');
       }
       else {
         body.classList.remove('rtl')
         i18n.changeLanguage('en');
       }
       window.scrollTo(0, 0);
       const fullPageLayoutRoutes = ['/user-pages/login-1', '/user-pages/register-1', '/user-pages/lockscreen', '/error-pages/error-404', '/error-pages/error-500', '/general-pages/landing-page'];
       for (let i = 0; i < fullPageLayoutRoutes.length; i++) {
         if (this.props.location.pathname === fullPageLayoutRoutes[i]) {
           this.setState({
             isFullPageLayout: true
           })
           document.querySelector('.page-body-wrapper').classList.add('full-page-wrapper');
           break;
         } else {
           this.setState({
             isFullPageLayout: false
           })
           document.querySelector('.page-body-wrapper').classList.remove('full-page-wrapper');
         }
       }
     }
   
   }
   
   export default withTranslation()(withRouter(App));
   