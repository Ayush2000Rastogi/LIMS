import React from 'react';
import ReactDOM from 'react-dom';
import { MemoryRouter } from 'react-router-dom';
import App from './app/App';
import "./i18n";
import * as serviceWorker from './serviceWorker';


ReactDOM.render(
  <MemoryRouter
    basename='/customercomplaint_app'
    initialEntries={["/customercomplaint_app/dashboard"]}>
    <App />
  </MemoryRouter>
  , document.getElementById('root'));

serviceWorker.unregister();